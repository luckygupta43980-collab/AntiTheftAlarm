# Anti-Theft Alarm (Android)

Open this folder in Android Studio (Hedgehog or newer), let Gradle sync,
then press Run with your phone connected (USB debugging on).

Requires Android 8.0+ and a screen lock (PIN / pattern / password).
