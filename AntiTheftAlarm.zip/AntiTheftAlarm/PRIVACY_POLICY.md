# Privacy Policy — Anti-Theft Alarm

_Last updated: [DATE]_

Anti-Theft Alarm ("the app") is made by **[YOUR NAME]** ([YOUR EMAIL]). The app protects the
owner's own phone from theft. This policy explains what data the app uses.

## Data the app uses

| Data | When | Where it goes |
|---|---|---|
| Motion sensor readings | While protection is on | Stays on the phone, not stored |
| Photos and a short video from the front camera | Only when the alarm goes off, and only if the owner turned this on | Saved on the phone (Pictures/AntiTheft, Movies/AntiTheft). If WhatsApp alerts are on: uploaded to Litterbox (litterbox.catbox.moe), which deletes them after 72 hours |
| Location (GPS / network) | Only while the alarm is ringing, and only if WhatsApp alerts are on | Sent as a Google Maps link to the owner's own WhatsApp number via CallMeBot (callmebot.com) |
| Alerts, photos, video and live location (Telegram) | Only when the alarm goes off, and only if the owner connected Telegram | Sent to the owner's own Telegram chat through Telegram's official Bot API (telegram.org) |
| Battery level | Together with the location | Same as location |
| The owner's WhatsApp number and CallMeBot API key | Entered by the owner | Stored only on the phone; sent to CallMeBot to deliver the message |

The app does **not** collect data for advertising or analytics, does not sell data, and does not
send anything to the developer.

## Third-party services
- **Telegram** (telegram.org) — delivers alerts, photos, video and live location to the owner's own chat.
- **CallMeBot** (callmebot.com) — delivers WhatsApp messages to the owner. See their privacy policy.
- **Litterbox by catbox.moe** — temporary file hosting for photos/videos (deleted after 72 hours).

## Your choices
Every feature (camera, video, location alerts) can be switched off in the app. Uninstalling the app
removes all its settings. Photos and videos saved on the phone can be deleted from the Gallery.

## Children
The app is not directed at children under 13.

## Contact
Questions: **[YOUR EMAIL]**
