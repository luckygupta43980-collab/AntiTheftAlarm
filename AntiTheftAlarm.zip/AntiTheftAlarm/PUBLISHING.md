# Publishing Anti-Theft Alarm on Google Play

## 1. Before the first upload
- Choose your app ID in `app/build.gradle.kts` (`val appId = ...`). It can never change later.
- Fill in [YOUR NAME], [YOUR EMAIL], [DATE] in PRIVACY_POLICY.md and publish it on a public web page
  (for example a free Google Sites page or a public GitHub Gist). Google Play needs its link.

## 2. Google Play Console
1. Create a developer account at play.google.com/console (one-time registration fee; identity check).
2. Create app → name "Anti-Theft Alarm", type App, Free.
3. Upload the `.aab` file from the GitHub "release-files" artifact (Testing → Internal testing first).
4. Turn on **Play App Signing** (default). Google keeps the final signing key; your GitHub key is only
   the "upload key". If you ever lose the upload key, Google support can reset it.
5. Fill in App content:
   - Privacy policy: link to your published policy.
   - Data safety: Location (approximate + precise), Photos and videos — collected, shared with third
     parties (CallMeBot, Litterbox) only when the user turns on WhatsApp alerts; used for app
     functionality (security); not used for ads; data is encrypted in transit (HTTPS).
   - Foreground service declaration: "special use" (anti-theft motion monitoring while the screen is
     off), "camera" (photo/video of the person who triggers the alarm), "location" (sending the
     phone's location to the owner during an alarm). Explain that each is started by the user.
   - Content rating questionnaire, target audience (18+ / adults), ads: No.
6. New personal developer accounts must run a **closed test** (at least 12 testers for 14 days)
   before they can publish to Production. Friends can be your testers.

## 3. Versions
- **play** flavor (uploaded to Google Play): no SMS, no power-menu blocking.
- **full** flavor (APK for your own phone, installed by USB): all features.
