package com.example.antitheft

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Accessibility service: while the alarm is armed (and the phone is locked) or ringing,
 * the moment the power-off / restart menu opens it is closed again, and the alarm starts.
 *
 * Note: the hardware "force restart" (holding Power + Volume Down ~10 s) cannot be
 * blocked by any app. For that case the alarm restarts itself after boot (BootReceiver).
 */
class PowerMenuBlocker : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastBlock = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) return
        if (!shouldProtect()) return
        if (isPowerMenu(e)) blockPowerMenu()
    }

    /** Protect while ringing, or while armed and the screen is locked. */
    private fun shouldProtect(): Boolean {
        if (Prefs.isRinging(this)) return true
        if (!Prefs.isArmed(this)) return false
        val km = getSystemService(KeyguardManager::class.java)
        return km?.isKeyguardLocked == true
    }

    private fun isPowerMenu(e: AccessibilityEvent): Boolean {
        val cls = e.className?.toString()?.lowercase(Locale.ROOT).orEmpty()
        if (CLASS_HINTS.any { cls.contains(it) }) return true
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = e.packageName?.toString().orEmpty()
            if (!isSystemPackage(pkg)) return false
        }
        return powerMenuVisible()
    }

    private fun powerMenuVisible(): Boolean {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try {
            windows.forEach { w -> w.root?.let { roots.add(it) } }
        } catch (_: Exception) {
        }
        for (root in roots) {
            if (!isSystemPackage(root.packageName?.toString().orEmpty())) continue
            for (text in POWER_TEXTS) {
                if (root.findAccessibilityNodeInfosByText(text).isNotEmpty()) return true
            }
        }
        return false
    }

    private fun isSystemPackage(pkg: String) =
        pkg == "android" || pkg.contains("systemui") || pkg.contains("powermenu") ||
            pkg.contains("globalactions")

    private fun blockPowerMenu() {
        val now = SystemClock.uptimeMillis()
        if (now - lastBlock < 300) return
        lastBlock = now

        performGlobalAction(GLOBAL_ACTION_BACK)
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        }
        // Some power menus ignore the first BACK: check again shortly
        handler.postDelayed({
            if (shouldProtect() && powerMenuVisible()) performGlobalAction(GLOBAL_ACTION_BACK)
        }, 400)

        // Someone is trying to switch the phone off -> start the alarm
        if (AlarmService.state == AlarmService.State.ARMED) {
            try {
                AlarmService.send(this, AlarmService.ACTION_TRIGGER)
            } catch (_: Exception) {
            }
        }
    }

    override fun onInterrupt() {}

    companion object {
        private val CLASS_HINTS = listOf(
            "globalactions", "powermenu", "powerdialog", "poweroff", "shutdown"
        )

        // Text shown on power menus (English + Hindi). Matching is case-insensitive.
        private val POWER_TEXTS = listOf(
            "Power off", "Switch off", "Turn off phone", "Restart", "Reboot",
            "बंद करें", "स्विच ऑफ़", "रीस्टार्ट", "पुनः आरंभ"
        )
    }
}
