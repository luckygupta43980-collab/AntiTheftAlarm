package com.example.antitheft

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Uploads a photo to Litterbox (free temporary image host by catbox.moe, no account needed).
 * The link works for 72 hours, then the photo is deleted automatically.
 * Blocking: call from a background thread.
 */
object PhotoUploader {
    private const val TAG = "PhotoUploader"
    private const val ENDPOINT = "https://litterbox.catbox.moe/resources/internals/api.php"

    /** Photo: resized JPEG. */
    fun upload(ctx: Context, uri: Uri): String? {
        val bytes = shrink(ctx, uri) ?: return null
        return post(bytes, "photo.jpg", "image/jpeg")
    }

    /** Video (or any file): uploaded as it is. */
    fun uploadVideo(ctx: Context, uri: Uri): String? {
        val bytes = try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            Log.w(TAG, "Cannot read video", e)
            null
        } ?: return null
        return post(bytes, "video.mp4", "video/mp4")
    }

    private fun post(bytes: ByteArray, fileName: String, mime: String): String? {
        return try {
            val boundary = "----AntiTheft${System.currentTimeMillis()}"
            val c = URL(ENDPOINT).openConnection() as HttpURLConnection
            c.doOutput = true
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = 120_000
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.outputStream.use { out ->
                fun field(name: String, value: String) = out.write(
                    "--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n"
                        .toByteArray()
                )
                field("reqtype", "fileupload")
                field("time", "72h")
                out.write(
                    ("--$boundary\r\nContent-Disposition: form-data; name=\"fileToUpload\"; " +
                        "filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n").toByteArray()
                )
                out.write(bytes)
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }?.trim().orEmpty()
            c.disconnect()
            if (code in 200..299 && body.startsWith("https://")) body else {
                Log.w(TAG, "Upload failed: HTTP $code $body")
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Upload failed", e)
            null
        }
    }

    /** Smaller JPEG (max 1600 px), turned the right way up, so it uploads fast on mobile data. */
    fun shrink(ctx: Context, uri: Uri): ByteArray? = try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2

        var bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("cannot decode photo")

        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )
        } ?: ExifInterface.ORIENTATION_NORMAL
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rotated != bmp) bmp.recycle()
            bmp = rotated
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        bmp.recycle()
        out.toByteArray()
    } catch (e: Exception) {
        Log.w(TAG, "Cannot read photo", e)
        null
    }
}
