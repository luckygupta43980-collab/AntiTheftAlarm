package com.example.antitheft

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Gets the phone's location and sends it as:
 *  - an SMS to the saved number, and/or
 *  - a WhatsApp message to your other phone (through the free CallMeBot service).
 */
class AlertSender(private val ctx: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var cancel: CancellationSignal? = null
    private var lastSent: Location? = null
    private var lastSentAt = 0L

    private fun smsReady() = Prefs.smsEnabled(ctx) && Prefs.phone(ctx).isNotBlank() &&
        granted(Manifest.permission.SEND_SMS)

    private fun waReady() = Prefs.waEnabled(ctx) && Prefs.waPhone(ctx).isNotBlank() &&
        Prefs.waApiKey(ctx).isNotBlank()

    /**
     * @param tryFreshFix get a new GPS/network fix (needs the service to be allowed
     *                    location access); otherwise only the last known location is used.
     */
    fun send(
        prefix: String,
        tryFreshFix: Boolean,
        useSms: Boolean = true,
        useWa: Boolean = true,
        onlyIfMoved: Boolean = false
    ) {
        if (!(useSms && smsReady()) && !(useWa && waReady())) return
        cancel?.cancel()   // a new request replaces any unfinished one

        val hasLocPermission = granted(Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        val lm = ctx.getSystemService(LocationManager::class.java)

        if (!hasLocPermission || lm == null) {
            deliver("$prefix\nLocation: not available", useSms, useWa)
            return
        }

        val provider = when {
            !tryFreshFix -> null
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            deliverLocation(prefix, lastKnown(lm), useSms, useWa, onlyIfMoved)
            return
        }

        var done = false
        val finish: (Location?) -> Unit = { loc ->
            if (!done) {
                done = true
                handler.removeCallbacksAndMessages(null)
                cancel?.cancel()
                deliverLocation(prefix, loc ?: lastKnown(lm), useSms, useWa, onlyIfMoved)
            }
        }

        val signal = CancellationSignal()
        cancel = signal
        try {
            LocationManagerCompat.getCurrentLocation(
                lm, provider, signal, ContextCompat.getMainExecutor(ctx)
            ) { loc -> finish(loc) }
        } catch (e: Exception) {
            finish(null)
            return
        }
        // GPS can be slow indoors: don't wait more than 30 seconds
        handler.postDelayed({ finish(null) }, 30_000)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        cancel?.cancel()
        cancel = null
        lastSent = null
        lastSentAt = 0L
    }

    private fun deliverLocation(
        prefix: String, loc: Location?, useSms: Boolean, useWa: Boolean, onlyIfMoved: Boolean
    ) {
        val prev = lastSent
        val now = SystemClock.elapsedRealtime()
        var movedText = ""
        if (loc != null && prev != null) {
            val moved = loc.distanceTo(prev).toInt()
            // Phone hasn't moved: skip this update (but still send one every 30 minutes)
            if (onlyIfMoved && moved < 30 && now - lastSentAt < 30 * 60_000) return
            movedText = if (moved >= 30) "\nMoved ${moved} m since last update" else "\nNot moving"
        }
        if (loc != null) {
            lastSent = loc
            lastSentAt = now
        }
        deliver("$prefix\n${format(loc)}$movedText", useSms, useWa)
    }

    private fun deliver(text: String, useSms: Boolean, useWa: Boolean) {
        val full = "$text\nBattery: ${battery()}%"
        if (useSms && smsReady()) sendSms(Prefs.phone(ctx), full)
        if (useWa && waReady()) sendWhatsAppWithRetry(full, attempt = 1)
    }

    /**
     * Uploads the thief photos and sends the links on WhatsApp (one message for all photos).
     * Retries up to 3 times, 1 minute apart, if there is no internet.
     */
    fun sendPhotos(uris: List<Uri>, attempt: Int = 1) {
        if (!waReady() || uris.isEmpty()) return
        Thread {
            val links = uris.mapNotNull { PhotoUploader.upload(ctx, it) }
            handler.post {
                if (links.isEmpty()) {
                    if (attempt < 3) handler.postDelayed({ sendPhotos(uris, attempt + 1) }, 60_000)
                    return@post
                }
                val text = "📸 PHOTOS of the person who touched your phone:\n" +
                    links.joinToString("\n") +
                    "\n(Open and save them — links expire in 3 days.)"
                sendWhatsAppWithRetry(text, attempt = 1)
            }
        }.start()
    }

    /** Uploads the thief video and sends the link on WhatsApp. */
    fun sendVideo(uri: Uri, attempt: Int = 1) {
        if (!waReady()) return
        Thread {
            val link = PhotoUploader.uploadVideo(ctx, uri)
            handler.post {
                if (link == null) {
                    if (attempt < 3) handler.postDelayed({ sendVideo(uri, attempt + 1) }, 60_000)
                    return@post
                }
                sendWhatsAppWithRetry(
                    "🎥 VIDEO of the person who touched your phone:\n$link\n" +
                        "(Open and save it — link expires in 3 days.)",
                    attempt = 1
                )
            }
        }.start()
    }

    /** Mobile data may be slow/unavailable: retry up to 3 times, 1 minute apart. */
    private fun sendWhatsAppWithRetry(text: String, attempt: Int) {
        sendWhatsApp(Prefs.waPhone(ctx), Prefs.waApiKey(ctx), text) { ok, _ ->
            if (!ok && attempt < 3) {
                handler.postDelayed({ sendWhatsAppWithRetry(text, attempt + 1) }, 60_000)
            }
        }
    }

    private fun battery(): Int = try {
        ctx.getSystemService(BatteryManager::class.java)
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    } catch (_: Exception) {
        -1
    }

    private fun lastKnown(lm: LocationManager): Location? = try {
        lm.getProviders(true)
            .mapNotNull { lm.getLastKnownLocation(it) }
            .maxByOrNull { it.time }
    } catch (e: SecurityException) {
        null
    }

    private fun format(loc: Location?): String =
        if (loc == null) "Location: not available"
        else String.format(
            Locale.US,
            "Location: https://maps.google.com/?q=%.6f,%.6f (accuracy %dm)",
            loc.latitude, loc.longitude, loc.accuracy.toInt()
        )

    private fun sendSms(number: String, text: String) {
        try {
            val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(number, null, parts, null, null)
        } catch (e: Exception) {
            Log.w(TAG, "SMS failed", e)
        }
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    companion object {
        private const val TAG = "AlertSender"

        /**
         * Sends a WhatsApp message to [phone] using the free CallMeBot API.
         * [phone] must be the number that requested the API key, with country code (+91...).
         * Runs on a background thread; [result] is called on the main thread.
         */
        fun sendWhatsApp(
            phone: String,
            apiKey: String,
            text: String,
            result: ((ok: Boolean, info: String) -> Unit)? = null
        ) {
            Thread {
                var ok = false
                var info: String
                try {
                    val url = URL(
                        "https://api.callmebot.com/whatsapp.php" +
                            "?phone=" + URLEncoder.encode(phone.replace(" ", ""), "UTF-8") +
                            "&text=" + URLEncoder.encode(text, "UTF-8") +
                            "&apikey=" + URLEncoder.encode(apiKey.trim(), "UTF-8")
                    )
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 15_000
                    c.readTimeout = 20_000
                    val code = c.responseCode
                    val body = (if (code in 200..299) c.inputStream else c.errorStream)
                        ?.bufferedReader()?.use { it.readText() }.orEmpty()
                    c.disconnect()
                    val plain = body.replace(Regex("<[^>]*>"), " ")
                        .replace(Regex("\\s+"), " ").trim()
                    val bad = listOf("invalid", "error", "not allowed", "blocked", "wait", "limit")
                        .any { plain.contains(it, ignoreCase = true) }
                    ok = code in 200..299 && !bad
                    // Always keep CallMeBot's own reply, so the user can see what went wrong
                    info = "HTTP $code: ${plain.take(200).ifBlank { "(empty reply)" }}"
                } catch (e: Exception) {
                    info = e.message ?: "network error"
                }
                Log.i(TAG, "WhatsApp: ok=$ok $info")
                result?.let { cb -> Handler(Looper.getMainLooper()).post { cb(ok, info) } }
            }.start()
        }
    }
}
