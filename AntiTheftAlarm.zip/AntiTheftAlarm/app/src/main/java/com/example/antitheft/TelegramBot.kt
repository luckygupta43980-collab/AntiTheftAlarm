package com.example.antitheft

import android.content.Context
import android.location.Location
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Official Telegram Bot API (free): sends alerts, real photos/videos and a LIVE location
 * (a map pin that keeps moving) to the owner's Telegram chat.
 * Everything is sent in order on one background thread.
 */
object TelegramBot {
    private const val TAG = "TelegramBot"
    private val queue = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var liveMessageId = 0L

    fun ready(c: Context) = Prefs.tgEnabled(c) && Prefs.tgToken(c).isNotBlank() &&
        Prefs.tgChatId(c).isNotBlank()

    // ------------------------------------------------------------ public (async)

    fun sendMessage(c: Context, text: String) {
        if (!ready(c)) return
        val ctx = c.applicationContext
        queue.execute { withRetry { call(ctx, "sendMessage", mapOf("text" to text)) } }
    }

    fun sendPhoto(c: Context, uri: Uri, caption: String) {
        if (!ready(c)) return
        val ctx = c.applicationContext
        queue.execute {
            val bytes = PhotoUploader.shrink(ctx, uri) ?: return@execute
            withRetry { upload(ctx, "sendPhoto", "photo", "photo.jpg", "image/jpeg", bytes, caption) }
        }
    }

    fun sendVideo(c: Context, uri: Uri, caption: String) {
        if (!ready(c)) return
        val ctx = c.applicationContext
        queue.execute {
            val bytes = try {
                ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (e: Exception) {
                null
            } ?: return@execute
            withRetry { upload(ctx, "sendVideo", "video", "video.mp4", "video/mp4", bytes, caption) }
        }
    }

    /** First call creates the live-location message; later calls move the pin. */
    fun updateLive(c: Context, loc: Location) {
        if (!ready(c)) return
        val ctx = c.applicationContext
        val fields = mapOf(
            "latitude" to loc.latitude.toString(),
            "longitude" to loc.longitude.toString(),
            "horizontal_accuracy" to loc.accuracy.coerceIn(0f, 1500f).toInt().toString()
        )
        queue.execute {
            if (liveMessageId == 0L) {
                val r = withRetry {
                    call(ctx, "sendLocation", fields + ("live_period" to "86400"))  // 24 hours
                }
                liveMessageId = r?.optJSONObject("result")?.optLong("message_id") ?: 0L
            } else {
                call(ctx, "editMessageLiveLocation", fields + ("message_id" to liveMessageId.toString()))
            }
        }
    }

    fun stopLive(c: Context, note: String?) {
        if (!ready(c)) return
        val ctx = c.applicationContext
        queue.execute {
            if (liveMessageId != 0L) {
                call(ctx, "stopMessageLiveLocation", mapOf("message_id" to liveMessageId.toString()))
                liveMessageId = 0L
            }
            if (note != null) call(ctx, "sendMessage", mapOf("text" to note))
        }
    }

    /**
     * Setup helper: finds the chat of the person who pressed START in the bot.
     * result(chatId, name, error) on the main thread.
     */
    fun findChat(token: String, result: (String?, String?, String?) -> Unit) {
        queue.execute {
            var chatId: String? = null
            var name: String? = null
            var error: String? = null
            try {
                val json = request(URL("https://api.telegram.org/bot${token.trim()}/getUpdates"), null)
                if (json == null || !json.optBoolean("ok")) {
                    error = json?.optString("description")?.ifBlank { null }
                        ?: "No reply from Telegram (check the token and the internet)"
                } else {
                    val updates = json.optJSONArray("result")
                    for (i in (updates?.length() ?: 0) - 1 downTo 0) {
                        val msg = updates!!.getJSONObject(i).optJSONObject("message") ?: continue
                        val chat = msg.optJSONObject("chat") ?: continue
                        chatId = chat.optLong("id").toString()
                        name = chat.optString("first_name").ifBlank { chat.optString("title") }
                        break
                    }
                    if (chatId == null) error = "NO_MESSAGES"
                }
            } catch (e: Exception) {
                error = e.message ?: "network error"
            }
            main.post { result(chatId, name, error) }
        }
    }

    /** Test message for the setup screen. result(ok, info) on the main thread. */
    fun sendTest(c: Context, text: String, result: (Boolean, String) -> Unit) {
        val ctx = c.applicationContext
        queue.execute {
            val r = call(ctx, "sendMessage", mapOf("text" to text))
            val ok = r?.optBoolean("ok") == true
            val info = r?.optString("description").orEmpty().ifBlank { if (ok) "sent" else "no reply" }
            main.post { result(ok, info) }
        }
    }

    // ------------------------------------------------------------ internals

    /** Retries up to 3 times, 30 s apart (no internet yet). Runs on the queue thread. */
    private fun withRetry(block: () -> JSONObject?): JSONObject? {
        repeat(3) { attempt ->
            val r = block()
            if (r?.optBoolean("ok") == true) return r
            if (attempt < 2) Thread.sleep(30_000)
        }
        return null
    }

    private fun call(ctx: Context, method: String, fields: Map<String, String>): JSONObject? {
        val all = fields + ("chat_id" to Prefs.tgChatId(ctx))
        val body = all.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        return request(
            URL("https://api.telegram.org/bot${Prefs.tgToken(ctx)}/$method"),
            body.toByteArray() to "application/x-www-form-urlencoded"
        )
    }

    private fun upload(
        ctx: Context, method: String, field: String, fileName: String, mime: String,
        bytes: ByteArray, caption: String
    ): JSONObject? {
        val boundary = "----AntiTheft${System.currentTimeMillis()}"
        val out = java.io.ByteArrayOutputStream()
        fun text(name: String, value: String) = out.write(
            "--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n"
                .toByteArray()
        )
        text("chat_id", Prefs.tgChatId(ctx))
        text("caption", caption)
        out.write(
            ("--$boundary\r\nContent-Disposition: form-data; name=\"$field\"; " +
                "filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n").toByteArray()
        )
        out.write(bytes)
        out.write("\r\n--$boundary--\r\n".toByteArray())
        return request(
            URL("https://api.telegram.org/bot${Prefs.tgToken(ctx)}/$method"),
            out.toByteArray() to "multipart/form-data; boundary=$boundary"
        )
    }

    private fun request(url: URL, body: Pair<ByteArray, String>?): JSONObject? = try {
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", body.second)
            c.outputStream.use { it.write(body.first) }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        JSONObject(txt)
    } catch (e: Exception) {
        Log.w(TAG, "Telegram request failed: ${url.path.substringAfterLast('/')}", e)
        null
    }
}
