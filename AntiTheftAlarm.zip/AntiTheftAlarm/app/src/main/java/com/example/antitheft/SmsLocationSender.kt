package com.example.antitheft

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import java.util.Locale

/** Sends an SMS to the saved emergency number with a Google Maps link. */
class SmsLocationSender(private val ctx: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var cancel: CancellationSignal? = null

    /**
     * @param tryFreshFix get a new GPS/network fix (needs the service to be allowed
     *                    location access); otherwise only the last known location is used.
     */
    fun send(prefix: String, tryFreshFix: Boolean) {
        val number = Prefs.phone(ctx)
        if (number.isBlank() || !granted(Manifest.permission.SEND_SMS)) return

        val hasLocPermission = granted(Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        val lm = ctx.getSystemService(LocationManager::class.java)

        if (!hasLocPermission || lm == null) {
            sendSms(number, "$prefix Location: not available")
            return
        }

        val provider = when {
            !tryFreshFix -> null
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            sendSms(number, "$prefix ${format(lastKnown(lm))}")
            return
        }

        var done = false
        val finish: (Location?) -> Unit = { loc ->
            if (!done) {
                done = true
                handler.removeCallbacksAndMessages(null)
                cancel?.cancel()
                sendSms(number, "$prefix ${format(loc ?: lastKnown(lm))}")
            }
        }

        val signal = CancellationSignal()
        cancel = signal
        try {
            LocationManagerCompat.getCurrentLocation(
                lm, provider, signal, ContextCompat.getMainExecutor(ctx)
            ) { loc -> finish(loc) }
        } catch (e: Exception) {
            finish(null)
            return
        }
        // GPS can be slow indoors: don't wait more than 30 seconds
        handler.postDelayed({ finish(null) }, 30_000)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        cancel?.cancel()
        cancel = null
    }

    private fun lastKnown(lm: LocationManager): Location? = try {
        lm.getProviders(true)
            .mapNotNull { lm.getLastKnownLocation(it) }
            .maxByOrNull { it.time }
    } catch (e: SecurityException) {
        null
    }

    private fun format(loc: Location?): String =
        if (loc == null) "Location: not available"
        else String.format(
            Locale.US,
            "Location: https://maps.google.com/?q=%.6f,%.6f (accuracy %dm)",
            loc.latitude, loc.longitude, loc.accuracy.toInt()
        )

    private fun sendSms(number: String, text: String) {
        try {
            val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(number, null, parts, null, null)
        } catch (e: Exception) {
            Log.w("SmsLocationSender", "SMS failed", e)
        }
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
