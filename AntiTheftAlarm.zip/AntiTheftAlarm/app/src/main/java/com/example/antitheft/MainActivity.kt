package com.example.antitheft

import android.Manifest
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.provider.Settings
import android.text.format.DateFormat
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Date

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STOP = "stop_alarm"

        private val DELAY_VALUES = intArrayOf(5, 10, 30, 60)
        private val DELAY_LABELS = arrayOf("5 seconds", "10 seconds", "30 seconds", "1 minute")

        private val PROTECT_VALUES = intArrayOf(0, 30, 60, 300, 900, 1800, 3600, 7200)
        private val PROTECT_LABELS = arrayOf(
            "Until I stop it", "30 seconds", "1 minute", "5 minutes",
            "15 minutes", "30 minutes", "1 hour", "2 hours"
        )

        private val GRACE_VALUES = intArrayOf(0, 5, 10, 15)
        private val GRACE_LABELS = arrayOf(
            "Instant — no warning", "5 seconds", "10 seconds", "15 seconds"
        )
    }

    private lateinit var tvStatus: TextView
    private lateinit var btnArm: Button
    private lateinit var btnStop: Button
    private lateinit var swSchedule: SwitchCompat
    private lateinit var btnFrom: Button
    private lateinit var btnTo: Button
    private lateinit var spDelay: Spinner
    private lateinit var spProtect: Spinner
    private lateinit var spGrace: Spinner
    private lateinit var rgSens: RadioGroup
    private lateinit var cbScreen: CheckBox
    private lateinit var cbFlash: CheckBox
    private lateinit var cbCharger: CheckBox
    private lateinit var cbPhoto: CheckBox
    private lateinit var cbVideo: CheckBox
    private lateinit var cbSms: CheckBox
    private lateinit var etPhone: EditText
    private lateinit var cbWa: CheckBox
    private lateinit var etWaPhone: EditText
    private lateinit var etWaKey: EditText
    private lateinit var btnWaTest: Button
    private lateinit var cbTg: CheckBox
    private lateinit var etTgToken: EditText
    private lateinit var btnTgConnect: Button
    private lateinit var tvTgStatus: TextView
    private lateinit var tvPowerStatus: TextView
    private lateinit var btnPowerProtect: Button

    private var ignoreSwitch = false
    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 500)
        }
    }

    private val confirmCredential =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                AlarmService.send(this, AlarmService.ACTION_DISARM, fromApp = true)
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var afterPermissions: (() -> Unit)? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val next = afterPermissions
            afterPermissions = null
            if (results.values.any { !it }) {
                Toast.makeText(
                    this,
                    "Some permissions were denied — those features will be skipped.",
                    Toast.LENGTH_LONG
                ).show()
            }
            next?.invoke()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Android 15+ draws edge-to-edge: keep content clear of the navigation bar / keyboard
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, 0, b.right, b.bottom)
            insets
        }

        tvStatus = findViewById(R.id.tvStatus)
        btnArm = findViewById(R.id.btnArm)
        btnStop = findViewById(R.id.btnStop)
        swSchedule = findViewById(R.id.swSchedule)
        btnFrom = findViewById(R.id.btnFrom)
        btnTo = findViewById(R.id.btnTo)
        spDelay = findViewById(R.id.spDelay)
        spProtect = findViewById(R.id.spProtect)
        spGrace = findViewById(R.id.spGrace)
        rgSens = findViewById(R.id.rgSens)
        cbScreen = findViewById(R.id.cbScreen)
        cbFlash = findViewById(R.id.cbFlash)
        cbCharger = findViewById(R.id.cbCharger)
        cbPhoto = findViewById(R.id.cbPhoto)
        cbVideo = findViewById(R.id.cbVideo)
        cbSms = findViewById(R.id.cbSms)
        etPhone = findViewById(R.id.etPhone)
        cbWa = findViewById(R.id.cbWa)
        etWaPhone = findViewById(R.id.etWaPhone)
        etWaKey = findViewById(R.id.etWaKey)
        btnWaTest = findViewById(R.id.btnWaTest)
        cbTg = findViewById(R.id.cbTg)
        etTgToken = findViewById(R.id.etTgToken)
        btnTgConnect = findViewById(R.id.btnTgConnect)
        tvTgStatus = findViewById(R.id.tvTgStatus)
        tvPowerStatus = findViewById(R.id.tvPowerStatus)
        btnPowerProtect = findViewById(R.id.btnPowerProtect)

        setupSpinner(spDelay, DELAY_LABELS, DELAY_VALUES.indexOf(Prefs.delaySeconds(this)))
        setupSpinner(spProtect, PROTECT_LABELS, PROTECT_VALUES.indexOf(Prefs.protectSeconds(this)))
        setupSpinner(spGrace, GRACE_LABELS, GRACE_VALUES.indexOf(Prefs.graceSeconds(this)))
        rgSens.check(
            when (Prefs.sensitivity(this)) {
                0 -> R.id.rbLow
                2 -> R.id.rbHigh
                else -> R.id.rbMedium
            }
        )
        cbScreen.isChecked = Prefs.screenAlarm(this)
        cbFlash.isChecked = Prefs.flashEnabled(this)
        cbCharger.isChecked = Prefs.chargerAlarm(this)
        cbPhoto.isChecked = Prefs.photoEnabled(this)
        cbVideo.isChecked = Prefs.videoEnabled(this)
        cbSms.isChecked = Prefs.smsEnabled(this)
        etPhone.setText(Prefs.phone(this))
        cbWa.isChecked = Prefs.waEnabled(this)
        etWaPhone.setText(Prefs.waPhone(this))
        etWaKey.setText(Prefs.waApiKey(this))
        cbTg.isChecked = Prefs.tgEnabled(this)
        etTgToken.setText(Prefs.tgToken(this))
        updateTgStatus()

        setSwitch(Prefs.scheduleEnabled(this))
        updateTimeButtons()
        swSchedule.setOnCheckedChangeListener { _, checked ->
            if (!ignoreSwitch) onScheduleToggled(checked)
        }
        btnFrom.setOnClickListener {
            pickTime(Prefs.schedStart(this)) { Prefs.setSchedStart(this, it); scheduleChanged() }
        }
        btnTo.setOnClickListener {
            pickTime(Prefs.schedEnd(this)) { Prefs.setSchedEnd(this, it); scheduleChanged() }
        }

        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        btnArm.setOnClickListener { arm() }
        btnStop.setOnClickListener { stopWithUnlock() }
        btnPowerProtect.setOnClickListener { showPowerProtectionHelp() }
        btnWaTest.setOnClickListener { sendTestWhatsApp() }
        btnTgConnect.setOnClickListener { connectTelegram() }

        // Google Play version: features that are only in the sideload version are hidden
        if (!BuildConfig.FEATURE_SMS) {
            cbSms.isChecked = false
            cbSms.visibility = View.GONE
            etPhone.visibility = View.GONE
            Prefs.setSmsEnabled(this, false)
        }
        if (!BuildConfig.FEATURE_POWER_BLOCK) {
            tvPowerStatus.visibility = View.GONE
            btnPowerProtect.visibility = View.GONE
        }

        if (!Prefs.disclosureAccepted(this)) showDisclosure()

        handleStopIntent(intent)
    }

    /** Prominent disclosure: what the app collects and where it goes (required by Google Play). */
    private fun showDisclosure() {
        AlertDialog.Builder(this)
            .setTitle("Before you start")
            .setMessage(
                "Anti-Theft Alarm protects YOUR phone. To do this it:\n\n" +
                    "• Uses the motion sensors while protection is on.\n" +
                    "• When the alarm goes off, can take photos and a 20-second video with the " +
                    "front camera. They are saved on this phone.\n" +
                    "• If you turn on Telegram alerts: sends alerts, the photos/video and this " +
                    "phone's live location to YOUR Telegram chat through Telegram's Bot API.\n" +
                    "• If you turn on WhatsApp alerts: sends this phone's location and battery " +
                    "level, and links to those photos/video, to YOUR WhatsApp number through the " +
                    "CallMeBot service. Photos/video are uploaded to Litterbox (catbox.moe) and " +
                    "deleted there after 72 hours.\n" +
                    "• Location is only used while the alarm is ringing.\n\n" +
                    "Nothing is sent anywhere else, and every feature can be turned off.\n\n" +
                    "Only use this app on your own phone. Taking photos or videos of other people " +
                    "may be regulated where you live."
            )
            .setCancelable(false)
            .setPositiveButton("I agree") { _, _ -> Prefs.setDisclosureAccepted(this, true) }
            .setNegativeButton("Close app") { _, _ -> finish() }
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleStopIntent(intent)
    }

    private fun handleStopIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_STOP, false) == true) {
            i.removeExtra(EXTRA_STOP)
            if (isProtecting()) stopWithUnlock()
        }
    }

    private fun isProtecting() = when (AlarmService.state) {
        AlarmService.State.COUNTDOWN, AlarmService.State.ARMED, AlarmService.State.RINGING -> true
        else -> false
    }

    private fun setupSpinner(sp: Spinner, labels: Array<String>, index: Int) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(if (index >= 0) index else 0)
    }

    // ------------------------------------------------------------ schedule

    private fun setSwitch(v: Boolean) {
        ignoreSwitch = true
        swSchedule.isChecked = v
        ignoreSwitch = false
    }

    private fun pickTime(current: Int, done: (Int) -> Unit) {
        TimePickerDialog(
            this, { _, h, m -> done(h * 60 + m) },
            current / 60, current % 60, DateFormat.is24HourFormat(this)
        ).show()
    }

    private fun updateTimeButtons() {
        btnFrom.text = "From  ${Schedule.label(this, Prefs.schedStart(this))}"
        btnTo.text = "To  ${Schedule.label(this, Prefs.schedEnd(this))}"
    }

    private fun scheduleChanged() {
        updateTimeButtons()
        if (Prefs.scheduleEnabled(this)) {
            AlarmService.send(this, AlarmService.ACTION_SCHEDULE, fromApp = true)
        }
    }

    private fun onScheduleToggled(on: Boolean) {
        if (!on) {
            Prefs.setScheduleEnabled(this, false)
            if (AlarmService.state != AlarmService.State.IDLE) {
                AlarmService.send(this, AlarmService.ACTION_SCHEDULE, fromApp = true)
            }
            return
        }
        if (!checkReady()) {
            setSwitch(false)
            return
        }
        savePrefs()
        askExactAlarmIfNeeded()
        withPermissions {
            Prefs.setScheduleEnabled(this, true)
            AlarmService.send(this, AlarmService.ACTION_SCHEDULE, fromApp = true)
            Toast.makeText(
                this,
                "Daily protection ON (${Schedule.rangeLabel(this)}). During these hours the " +
                    "phone is protected whenever the screen is locked.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Play version: exact start/end times need "Alarms & reminders" permission (Android 12+). */
    private fun askExactAlarmIfNeeded() {
        if (Build.VERSION.SDK_INT < 31) return
        val am = getSystemService(AlarmManager::class.java)
        if (am.canScheduleExactAlarms()) return
        AlertDialog.Builder(this)
            .setTitle("Start and stop exactly on time")
            .setMessage(
                "To switch protection on and off exactly at your chosen times, allow " +
                    "\"Alarms & reminders\" for this app on the next screen. Without it, " +
                    "Android may start or stop it a few minutes late."
            )
            .setPositiveButton("Allow") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {}
            }
            .setNegativeButton("Not now", null)
            .show()
    }

    // ------------------------------------------------------------ manual protection

    private fun arm() {
        if (!checkReady()) return
        savePrefs()
        withPermissions {
            AlarmService.send(this, AlarmService.ACTION_ARM)
            Toast.makeText(
                this,
                "Lock the screen and put the phone down. 2 beeps = protection has started.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Screen lock + SMS/WhatsApp details must be OK before protecting. */
    private fun checkReady(): Boolean {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) {
            AlertDialog.Builder(this)
                .setTitle("Screen lock required")
                .setMessage(
                    "The alarm is turned off with your phone's PIN, pattern or password. " +
                        "Without a screen lock, anyone could stop it. Please set one first."
                )
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return false
        }
        if (cbSms.isChecked && etPhone.text.isNullOrBlank()) {
            etPhone.error = "Enter a phone number for the SMS alert"
            etPhone.requestFocus()
            return false
        }
        if (cbWa.isChecked && !validWhatsApp()) return false
        if (cbTg.isChecked && Prefs.tgChatId(this).isBlank()) {
            etTgToken.error = "Tap CONNECT TELEGRAM first"
            etTgToken.requestFocus()
            return false
        }
        return true
    }

    private fun withPermissions(then: () -> Unit) {
        val needed = buildList {
            if (cbPhoto.isChecked || cbVideo.isChecked) add(Manifest.permission.CAMERA)
            if (cbSms.isChecked) add(Manifest.permission.SEND_SMS)
            if (cbSms.isChecked || cbWa.isChecked || cbTg.isChecked) {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
                add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
        }.filter { !granted(it) }
        if (needed.isEmpty()) then() else {
            afterPermissions = then
            permLauncher.launch(needed.toTypedArray())
        }
    }

    private fun validWhatsApp(): Boolean {
        val phone = etWaPhone.text.toString().replace(" ", "")
        if (!phone.startsWith("+") || phone.length < 10) {
            etWaPhone.error = "Enter the WhatsApp number with country code, e.g. +919876543210"
            etWaPhone.requestFocus()
            return false
        }
        if (etWaKey.text.isNullOrBlank()) {
            etWaKey.error = "Enter the API key you got from CallMeBot"
            etWaKey.requestFocus()
            return false
        }
        return true
    }

    private fun sendTestWhatsApp() {
        if (!validWhatsApp()) return
        savePrefs()
        btnWaTest.isEnabled = false
        Toast.makeText(this, "Sending test message…", Toast.LENGTH_SHORT).show()
        AlertSender.sendWhatsApp(
            Prefs.waPhone(this), Prefs.waApiKey(this),
            "✅ Anti-Theft Alarm: test message. WhatsApp alerts are working!"
        ) { ok, info ->
            btnWaTest.isEnabled = true
            AlertDialog.Builder(this)
                .setTitle(if (ok) "✅ Sent" else "❌ Not sent")
                .setMessage(
                    (if (ok) "Check WhatsApp on your other phone (can take up to 1 minute).\n\n"
                    else "WhatsApp message failed.\n\n") +
                        "Number used: ${Prefs.waPhone(this)}\n\nCallMeBot replied:\n$info"
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    // ------------------------------------------------------------ Telegram

    private fun updateTgStatus() {
        val chat = Prefs.tgChatId(this)
        tvTgStatus.text = if (chat.isNotBlank())
            "Connected ✅ — alerts go to ${Prefs.tgChatName(this).ifBlank { "your chat" }}"
        else "Not connected yet"
    }

    private fun connectTelegram() {
        val token = etTgToken.text.toString().trim()
        if (!token.contains(":") || token.length < 30) {
            etTgToken.error = "Paste the full token from @BotFather (looks like 123456789:AAH...)"
            etTgToken.requestFocus()
            return
        }
        if (token != Prefs.tgToken(this)) Prefs.setTgChatId(this, "")
        Prefs.setTgToken(this, token)
        btnTgConnect.isEnabled = false
        Toast.makeText(this, "Connecting to Telegram…", Toast.LENGTH_SHORT).show()
        TelegramBot.findChat(token) { chatId, name, error ->
            if (chatId == null) {
                btnTgConnect.isEnabled = true
                val msg = if (error == "NO_MESSAGES")
                    "The token is correct, but your bot has no messages yet.\n\n" +
                        "On your OTHER phone: open your bot in Telegram, tap START " +
                        "(or send it \"hi\"), then tap CONNECT TELEGRAM here again."
                else "Could not connect:\n$error\n\nCheck the token and the internet connection."
                AlertDialog.Builder(this).setTitle("Telegram").setMessage(msg)
                    .setPositiveButton("OK", null).show()
                return@findChat
            }
            Prefs.setTgChatId(this, chatId)
            Prefs.setTgChatName(this, name.orEmpty())
            cbTg.isChecked = true
            Prefs.setTgEnabled(this, true)
            TelegramBot.sendTest(
                this, "✅ Anti-Theft Alarm is connected! Alerts, photos, video and live location " +
                    "will arrive in this chat."
            ) { ok, info ->
                btnTgConnect.isEnabled = true
                updateTgStatus()
                AlertDialog.Builder(this)
                    .setTitle(if (ok) "✅ Connected" else "❌ Test message failed")
                    .setMessage(
                        if (ok) "A test message was sent to ${name ?: "your chat"}. Check Telegram " +
                            "on your other phone."
                        else "Telegram replied: $info"
                    )
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun savePrefs() {
        Prefs.setDelaySeconds(this, DELAY_VALUES[spDelay.selectedItemPosition])
        Prefs.setProtectSeconds(this, PROTECT_VALUES[spProtect.selectedItemPosition])
        Prefs.setGraceSeconds(this, GRACE_VALUES[spGrace.selectedItemPosition])
        Prefs.setSensitivity(
            this,
            when (rgSens.checkedRadioButtonId) {
                R.id.rbLow -> 0
                R.id.rbHigh -> 2
                else -> 1
            }
        )
        Prefs.setScreenAlarm(this, cbScreen.isChecked)
        Prefs.setFlashEnabled(this, cbFlash.isChecked)
        Prefs.setChargerAlarm(this, cbCharger.isChecked)
        Prefs.setPhotoEnabled(this, cbPhoto.isChecked)
        Prefs.setVideoEnabled(this, cbVideo.isChecked)
        Prefs.setSmsEnabled(this, cbSms.isChecked)
        Prefs.setPhone(this, etPhone.text.toString())
        Prefs.setWaEnabled(this, cbWa.isChecked)
        Prefs.setWaPhone(this, etWaPhone.text.toString())
        Prefs.setWaApiKey(this, etWaKey.text.toString())
        Prefs.setTgEnabled(this, cbTg.isChecked)
    }

    @Suppress("DEPRECATION")
    private fun stopWithUnlock() {
        val km = getSystemService(KeyguardManager::class.java)
        val intent = km.createConfirmDeviceCredentialIntent(
            "Stop anti-theft alarm",
            "Enter your phone PIN, pattern or password"
        )
        if (intent != null) confirmCredential.launch(intent)
        else AlarmService.send(this, AlarmService.ACTION_DISARM, fromApp = true)
    }

    // ------------------------------------------------------------ UI

    private fun refreshUi() {
        val state = AlarmService.state
        tvStatus.text = when {
            AlarmService.warning -> "⚠️ UNLOCK NOW!\nSiren in ${AlarmService.warningLeft} s"
            state == AlarmService.State.IDLE -> "Status: OFF"
            state == AlarmService.State.STANDBY ->
                if (Schedule.isActive(this))
                    "🕗 DAILY PROTECTION\nStarts when you lock the screen"
                else
                    "🕗 DAILY PROTECTION\nNext start: ${Schedule.label(this, Prefs.schedStart(this))}"
            state == AlarmService.State.COUNTDOWN ->
                "Put the phone down…\nProtection starts in ${AlarmService.countdownLeft} s"
            state == AlarmService.State.ARMED -> {
                if (Prefs.armSource(this) == AlarmService.SOURCE_SCHEDULE) {
                    "PROTECTED 🔒\n(daily, until ${Schedule.label(this, Prefs.schedEnd(this))})"
                } else {
                    val until = Prefs.protectUntil(this)
                    if (until > 0) {
                        val left = ((until - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
                        "PROTECTED 🔒\n${left / 60}:${"%02d".format(left % 60)} left " +
                            "(until ${DateFormat.getTimeFormat(this).format(Date(until))})"
                    } else {
                        "PROTECTED 🔒\n(until you stop it)"
                    }
                }
            }
            else -> "🚨 ALARM RINGING"
        }

        val editable = !isProtecting()
        btnArm.isEnabled = editable
        btnStop.isEnabled = isProtecting()
        btnStop.text = if (state == AlarmService.State.RINGING)
            "STOP ALARM (needs PIN)" else "STOP (needs PIN)"
        listOf(
            spDelay, spProtect, spGrace, cbScreen, cbFlash, cbCharger, cbPhoto, cbVideo,
            cbSms, etPhone, cbWa, etWaPhone, etWaKey, cbTg, etTgToken, btnTgConnect,
            swSchedule, btnFrom, btnTo
        ).forEach { it.isEnabled = editable }
        for (i in 0 until rgSens.childCount) rgSens.getChildAt(i).isEnabled = editable

        val protectedOn = isPowerProtectionOn()
        tvPowerStatus.text = if (protectedOn)
            "Power-off protection: ON ✅"
        else
            "Power-off protection: OFF ⚠️"
        btnPowerProtect.text =
            if (protectedOn) "Power-off protection settings" else "Turn on power-off protection"
    }

    private fun isPowerProtectionOn(): Boolean {
        if (!BuildConfig.FEATURE_POWER_BLOCK) return false
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        // The service only exists in the sideload ("full") version
        val me = ComponentName(this, "com.example.antitheft.PowerMenuBlocker")
        return enabled.split(':').any {
            it.equals(me.flattenToString(), true) || it.equals(me.flattenToShortString(), true)
        }
    }

    private fun showPowerProtectionHelp() {
        AlertDialog.Builder(this)
            .setTitle("Power-off protection")
            .setMessage(
                "1. Tap OPEN to go to Accessibility settings.\n" +
                    "2. Find \"Anti-Theft power-off protection\" (it may be under " +
                    "\"Installed apps\" or \"Downloaded apps\") and turn it on.\n\n" +
                    "If it is greyed out or says \"Restricted setting\": go to Settings → Apps → " +
                    "Anti-Theft Alarm → tap ⋮ (top-right) → \"Allow restricted settings\", " +
                    "then try again."
            )
            .setPositiveButton("Open") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (AlarmService.state == AlarmService.State.RINGING &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
                keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                keyCode == KeyEvent.KEYCODE_VOLUME_MUTE)
        ) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
        // After a restart the background service can't use camera/location until the app is opened
        if (Prefs.scheduleEnabled(this) && !isProtecting()) {
            AlarmService.send(this, AlarmService.ACTION_SCHEDULE, fromApp = true)
        }
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        if (!isProtecting()) savePrefs()   // settings changes apply to the next protection
        super.onPause()
    }
}
