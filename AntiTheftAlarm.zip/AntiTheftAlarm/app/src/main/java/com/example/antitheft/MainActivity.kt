package com.example.antitheft

import android.Manifest
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STOP = "stop_alarm"
    }

    private lateinit var tvStatus: TextView
    private lateinit var btnArm: Button
    private lateinit var btnStop: Button
    private lateinit var rgDelay: RadioGroup
    private lateinit var rgSens: RadioGroup
    private lateinit var cbCharger: CheckBox
    private lateinit var cbPhoto: CheckBox
    private lateinit var cbSms: CheckBox
    private lateinit var etPhone: EditText
    private lateinit var tvPowerStatus: TextView
    private lateinit var btnPowerProtect: Button

    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 500)
        }
    }

    // Stopping from inside the app requires the phone's PIN / pattern / password
    private val confirmCredential =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                AlarmService.send(this, AlarmService.ACTION_DISARM)
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var pendingArm = false
    private val armPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            if (!pendingArm) return@registerForActivityResult
            pendingArm = false
            if (results.values.any { !it }) {
                Toast.makeText(
                    this,
                    "Some permissions were denied — those features will be skipped.",
                    Toast.LENGTH_LONG
                ).show()
            }
            startArming()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnArm = findViewById(R.id.btnArm)
        btnStop = findViewById(R.id.btnStop)
        rgDelay = findViewById(R.id.rgDelay)
        rgSens = findViewById(R.id.rgSens)
        cbCharger = findViewById(R.id.cbCharger)
        cbPhoto = findViewById(R.id.cbPhoto)
        cbSms = findViewById(R.id.cbSms)
        etPhone = findViewById(R.id.etPhone)
        tvPowerStatus = findViewById(R.id.tvPowerStatus)
        btnPowerProtect = findViewById(R.id.btnPowerProtect)
        btnPowerProtect.setOnClickListener { showPowerProtectionHelp() }

        rgDelay.check(
            when (Prefs.delaySeconds(this)) {
                5 -> R.id.rbDelay5
                30 -> R.id.rbDelay30
                else -> R.id.rbDelay10
            }
        )
        rgSens.check(
            when (Prefs.sensitivity(this)) {
                0 -> R.id.rbLow
                2 -> R.id.rbHigh
                else -> R.id.rbMedium
            }
        )
        cbCharger.isChecked = Prefs.chargerAlarm(this)
        cbPhoto.isChecked = Prefs.photoEnabled(this)
        cbSms.isChecked = Prefs.smsEnabled(this)
        etPhone.setText(Prefs.phone(this))

        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        btnArm.setOnClickListener { arm() }
        btnStop.setOnClickListener { stopWithUnlock() }

        handleStopIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleStopIntent(intent)
    }

    /** Opened from the "STOP ALARM" notification -> ask for the PIN straight away. */
    private fun handleStopIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_STOP, false) == true) {
            i.removeExtra(EXTRA_STOP)
            if (AlarmService.state != AlarmService.State.IDLE) stopWithUnlock()
        }
    }

    private fun arm() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) {
            AlertDialog.Builder(this)
                .setTitle("Screen lock required")
                .setMessage(
                    "The alarm is turned off by unlocking the phone. Without a PIN, pattern " +
                        "or password, anyone could stop it. Please set a screen lock first."
                )
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        if (cbSms.isChecked && etPhone.text.isNullOrBlank()) {
            etPhone.error = "Enter a phone number for the SMS alert"
            etPhone.requestFocus()
            return
        }

        savePrefs()

        val needed = buildList {
            if (cbPhoto.isChecked) add(Manifest.permission.CAMERA)
            if (cbSms.isChecked) {
                add(Manifest.permission.SEND_SMS)
                add(Manifest.permission.ACCESS_FINE_LOCATION)
                add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
        }.filter { !granted(it) }

        if (needed.isNotEmpty()) {
            pendingArm = true
            armPermissions.launch(needed.toTypedArray())
        } else {
            startArming()
        }
    }

    private fun startArming() {
        AlarmService.send(this, AlarmService.ACTION_ARM)
        if (!isPowerProtectionOn()) {
            Toast.makeText(
                this,
                "Tip: turn on power-off protection so a thief can't switch the phone off.",
                Toast.LENGTH_LONG
            ).show()
        }
        Toast.makeText(
            this,
            "Now press the POWER button to lock the screen and put the phone down.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun savePrefs() {
        Prefs.setDelaySeconds(
            this,
            when (rgDelay.checkedRadioButtonId) {
                R.id.rbDelay5 -> 5
                R.id.rbDelay30 -> 30
                else -> 10
            }
        )
        Prefs.setSensitivity(
            this,
            when (rgSens.checkedRadioButtonId) {
                R.id.rbLow -> 0
                R.id.rbHigh -> 2
                else -> 1
            }
        )
        Prefs.setChargerAlarm(this, cbCharger.isChecked)
        Prefs.setPhotoEnabled(this, cbPhoto.isChecked)
        Prefs.setSmsEnabled(this, cbSms.isChecked)
        Prefs.setPhone(this, etPhone.text.toString())
    }

    @Suppress("DEPRECATION")
    private fun stopWithUnlock() {
        val km = getSystemService(KeyguardManager::class.java)
        val intent = km.createConfirmDeviceCredentialIntent(
            "Stop anti-theft alarm",
            "Enter your phone PIN, pattern or password"
        )
        if (intent != null) confirmCredential.launch(intent)
        else AlarmService.send(this, AlarmService.ACTION_DISARM)
    }

    private fun refreshUi() {
        val state = AlarmService.state
        tvStatus.text = when (state) {
            AlarmService.State.IDLE -> "Status: OFF"
            AlarmService.State.COUNTDOWN -> "Status: Arming in ${AlarmService.countdownLeft} s…"
            AlarmService.State.ARMED -> "Status: ARMED 🔒"
            AlarmService.State.RINGING -> "Status: 🚨 ALARM RINGING"
        }
        val idle = state == AlarmService.State.IDLE
        btnArm.isEnabled = idle
        btnStop.isEnabled = !idle
        btnStop.text = if (state == AlarmService.State.RINGING)
            "STOP ALARM (needs PIN)" else "STOP (needs PIN)"
        for (i in 0 until rgDelay.childCount) rgDelay.getChildAt(i).isEnabled = idle
        for (i in 0 until rgSens.childCount) rgSens.getChildAt(i).isEnabled = idle
        cbCharger.isEnabled = idle
        cbPhoto.isEnabled = idle
        cbSms.isEnabled = idle
        etPhone.isEnabled = idle

        val protectedOn = isPowerProtectionOn()
        tvPowerStatus.text = if (protectedOn)
            "Power-off protection: ON ✅"
        else
            "Power-off protection: OFF ⚠️"
        btnPowerProtect.text = if (protectedOn) "Power-off protection settings" else "Turn on power-off protection"
    }

    private fun isPowerProtectionOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, PowerMenuBlocker::class.java)
        return enabled.split(':').any {
            it.equals(me.flattenToString(), true) || it.equals(me.flattenToShortString(), true)
        }
    }

    private fun showPowerProtectionHelp() {
        AlertDialog.Builder(this)
            .setTitle("Power-off protection")
            .setMessage(
                "1. Tap OPEN to go to Accessibility settings.\n" +
                    "2. Find \"Anti-Theft power-off protection\" (it may be under " +
                    "\"Installed apps\" or \"Downloaded apps\") and turn it on.\n\n" +
                    "If it is greyed out or says \"Restricted setting\": go to Settings → Apps → " +
                    "Anti-Theft Alarm → tap ⋮ (top-right) → \"Allow restricted settings\", " +
                    "then try again."
            )
            .setPositiveButton("Open") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // Block the volume buttons while the alarm screen is open and ringing
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (AlarmService.state == AlarmService.State.RINGING &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
                keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                keyCode == KeyEvent.KEYCODE_VOLUME_MUTE)
        ) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }
}
