package com.example.antitheft

import android.content.Context

/**
 * Settings stored in device-protected storage, so they can be read
 * right after a reboot even before the owner unlocks the phone.
 */
object Prefs {
    private fun sp(c: Context) =
        c.createDeviceProtectedStorageContext()
            .getSharedPreferences("antitheft", Context.MODE_PRIVATE)

    fun isArmed(c: Context) = sp(c).getBoolean("armed", false)
    fun setArmed(c: Context, v: Boolean) { sp(c).edit().putBoolean("armed", v).commit() }

    fun isRinging(c: Context) = sp(c).getBoolean("ringing", false)
    fun setRinging(c: Context, v: Boolean) { sp(c).edit().putBoolean("ringing", v).commit() }

    /** Seconds to wait after pressing ARM before the alarm becomes active. */
    fun delaySeconds(c: Context) = sp(c).getInt("delay", 10)
    fun setDelaySeconds(c: Context, v: Int) { sp(c).edit().putInt("delay", v).apply() }

    /** 0 = low, 1 = medium, 2 = high */
    fun sensitivity(c: Context) = sp(c).getInt("sens", 1)
    fun setSensitivity(c: Context, v: Int) { sp(c).edit().putInt("sens", v).apply() }

    /** Movement (m/s², summed over x/y/z) needed to trigger the alarm. */
    fun threshold(c: Context) = when (sensitivity(c)) {
        0 -> 3.0f
        2 -> 0.6f
        else -> 1.5f
    }

    fun chargerAlarm(c: Context) = sp(c).getBoolean("charger", false)
    fun setChargerAlarm(c: Context, v: Boolean) { sp(c).edit().putBoolean("charger", v).apply() }

    fun photoEnabled(c: Context) = sp(c).getBoolean("photo", false)
    fun setPhotoEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("photo", v).apply() }

    fun smsEnabled(c: Context) = sp(c).getBoolean("sms", false)
    fun setSmsEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("sms", v).apply() }

    fun phone(c: Context) = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, v: String) { sp(c).edit().putString("phone", v.trim()).apply() }
}
