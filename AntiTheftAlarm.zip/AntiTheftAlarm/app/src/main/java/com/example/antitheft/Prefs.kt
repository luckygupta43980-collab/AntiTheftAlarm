package com.example.antitheft

import android.content.Context

/**
 * Settings stored in device-protected storage, so they can be read
 * right after a reboot even before the owner unlocks the phone.
 */
object Prefs {
    private fun sp(c: Context) =
        c.createDeviceProtectedStorageContext()
            .getSharedPreferences("antitheft", Context.MODE_PRIVATE)

    fun isArmed(c: Context) = sp(c).getBoolean("armed", false)
    fun setArmed(c: Context, v: Boolean) { sp(c).edit().putBoolean("armed", v).commit() }

    fun isRinging(c: Context) = sp(c).getBoolean("ringing", false)
    fun setRinging(c: Context, v: Boolean) { sp(c).edit().putBoolean("ringing", v).commit() }

    /** Seconds to put the phone down after pressing ARM (not protected yet). */
    fun delaySeconds(c: Context) = sp(c).getInt("delay", 10)
    fun setDelaySeconds(c: Context, v: Int) { sp(c).edit().putInt("delay", v).apply() }

    /** How long the phone stays protected. 0 = until the owner stops it. */
    fun protectSeconds(c: Context) = sp(c).getInt("protect", 0)
    fun setProtectSeconds(c: Context, v: Int) { sp(c).edit().putInt("protect", v).apply() }

    /** Wall-clock time (ms) when protection ends. 0 = no end time. */
    fun protectUntil(c: Context) = sp(c).getLong("protect_until", 0L)
    fun setProtectUntil(c: Context, v: Long) { sp(c).edit().putLong("protect_until", v).commit() }

    /** 0 = low, 1 = medium, 2 = high */
    fun sensitivity(c: Context) = sp(c).getInt("sens", 1)
    fun setSensitivity(c: Context, v: Int) { sp(c).edit().putInt("sens", v).apply() }

    fun chargerAlarm(c: Context) = sp(c).getBoolean("charger", false)
    fun setChargerAlarm(c: Context, v: Boolean) { sp(c).edit().putBoolean("charger", v).apply() }

    fun screenAlarm(c: Context) = sp(c).getBoolean("screen", false)
    fun setScreenAlarm(c: Context, v: Boolean) { sp(c).edit().putBoolean("screen", v).apply() }

    fun flashEnabled(c: Context) = sp(c).getBoolean("flash", true)
    fun setFlashEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("flash", v).apply() }

    fun photoEnabled(c: Context) = sp(c).getBoolean("photo", false)
    fun setPhotoEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("photo", v).apply() }

    fun videoEnabled(c: Context) = sp(c).getBoolean("video", false)
    fun setVideoEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("video", v).apply() }

    fun smsEnabled(c: Context) = sp(c).getBoolean("sms", false)
    fun setSmsEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("sms", v).apply() }

    // Daily schedule (minutes after midnight)
    fun scheduleEnabled(c: Context) = sp(c).getBoolean("sched", false)
    fun setScheduleEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("sched", v).commit() }

    fun schedStart(c: Context) = sp(c).getInt("sched_start", 8 * 60)
    fun setSchedStart(c: Context, v: Int) { sp(c).edit().putInt("sched_start", v).commit() }

    fun schedEnd(c: Context) = sp(c).getInt("sched_end", 20 * 60)
    fun setSchedEnd(c: Context, v: Int) { sp(c).edit().putInt("sched_end", v).commit() }

    /** "manual" (START button) or "schedule" */
    fun armSource(c: Context) = sp(c).getString("arm_source", "manual") ?: "manual"
    fun setArmSource(c: Context, v: String) { sp(c).edit().putString("arm_source", v).commit() }

    /** Seconds of soft warning before the siren, so the owner can unlock (0 = instant). */
    fun graceSeconds(c: Context) = sp(c).getInt("grace", 0)
    fun setGraceSeconds(c: Context, v: Int) { sp(c).edit().putInt("grace", v).apply() }

    fun phone(c: Context) = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, v: String) { sp(c).edit().putString("phone", v.trim()).apply() }

    // WhatsApp alerts through CallMeBot
    fun waEnabled(c: Context) = sp(c).getBoolean("wa", false)
    fun setWaEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("wa", v).apply() }

    fun waPhone(c: Context) = sp(c).getString("wa_phone", "") ?: ""
    fun setWaPhone(c: Context, v: String) { sp(c).edit().putString("wa_phone", v.replace(" ", "")).apply() }

    fun waApiKey(c: Context) = sp(c).getString("wa_key", "") ?: ""
    fun setWaApiKey(c: Context, v: String) { sp(c).edit().putString("wa_key", v.trim()).apply() }
}
