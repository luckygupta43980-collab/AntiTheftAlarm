package com.example.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * - If the phone was switched off while protected or ringing, the alarm rings again
 *   as soon as it boots (before anyone unlocks it).
 * - Otherwise, if the daily schedule is on, it is started again.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_LOCKED_BOOT_COMPLETED && action != Intent.ACTION_BOOT_COMPLETED) return
        when {
            Prefs.isArmed(context) || Prefs.isRinging(context) ->
                AlarmService.send(context, AlarmService.ACTION_TRIGGER, fromBoot = true)
            Prefs.scheduleEnabled(context) ->
                AlarmService.send(context, AlarmService.ACTION_SCHEDULE)
        }
    }
}
