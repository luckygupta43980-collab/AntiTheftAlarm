package com.example.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * If the phone was switched off while the alarm was armed or ringing,
 * the alarm starts ringing again as soon as the phone boots up —
 * even before anyone unlocks it — and keeps ringing until the owner unlocks.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_LOCKED_BOOT_COMPLETED || action == Intent.ACTION_BOOT_COMPLETED) {
            if (Prefs.isArmed(context) || Prefs.isRinging(context)) {
                AlarmService.send(context, AlarmService.ACTION_TRIGGER, fromBoot = true)
            }
        }
    }
}
