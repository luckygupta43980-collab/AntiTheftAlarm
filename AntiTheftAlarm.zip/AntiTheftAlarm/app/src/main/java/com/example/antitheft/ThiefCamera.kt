package com.example.antitheft

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Silently (no preview on screen) takes photos and then a short video with the front camera.
 * Saved to Gallery: Pictures/AntiTheft and Movies/AntiTheft.
 */
class ThiefCamera(private val owner: LifecycleService) {

    private val handler = Handler(Looper.getMainLooper())
    private var provider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var recording: Recording? = null
    private var running = false

    private var remaining = 0
    private var interval = 3000L
    private var videoSeconds = 0
    private var currentFile: File? = null

    private var onPhoto: ((Uri) -> Unit)? = null
    private var onPhotosDone: (() -> Unit)? = null
    private var onVideo: ((Uri) -> Unit)? = null
    private var onDone: (() -> Unit)? = null

    /**
     * @param photoCount  number of photos (0 = none)
     * @param videoSecs   length of the video clip in seconds (0 = no video)
     * @param photo       called with each saved photo
     * @param photosDone  called when the photo part is finished
     * @param video       called with the saved video
     * @param done        called when everything is finished (or the camera is unavailable)
     */
    fun start(
        photoCount: Int = 3,
        intervalMs: Long = 3000,
        videoSecs: Int = 0,
        photo: ((Uri) -> Unit)? = null,
        photosDone: (() -> Unit)? = null,
        video: ((Uri) -> Unit)? = null,
        done: (() -> Unit)? = null
    ) {
        if (ContextCompat.checkSelfPermission(owner, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            photosDone?.invoke()
            done?.invoke()
            return
        }
        if (running) return
        running = true
        remaining = photoCount
        interval = intervalMs
        videoSeconds = videoSecs
        onPhoto = photo
        onPhotosDone = photosDone
        onVideo = video
        onDone = done

        val future = ProcessCameraProvider.getInstance(owner)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                if (remaining > 0) {
                    val ic = ImageCapture.Builder().build()
                    p.unbindAll()
                    p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, ic)
                    imageCapture = ic
                }
                // give auto-exposure a moment so the photo isn't black
                handler.postDelayed({ shootNext() }, 1500)
            } catch (e: Exception) {
                Log.w(TAG, "Front camera not available", e)
                photosFinished()
                finish()
            }
        }, ContextCompat.getMainExecutor(owner))
    }

    // ------------------------------------------------------------- photos

    private fun shootNext() {
        if (!running) return
        val ic = imageCapture
        if (remaining <= 0 || ic == null) {
            photosFinished()
            startVideo()
            return
        }
        remaining--
        ic.takePicture(
            photoOptions(),
            ContextCompat.getMainExecutor(owner),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    val uri = r.savedUri ?: currentFile?.let { Uri.fromFile(it) }
                    uri?.let { onPhoto?.invoke(it) }
                    handler.postDelayed({ shootNext() }, interval)
                }

                override fun onError(e: ImageCaptureException) {
                    Log.w(TAG, "Photo failed", e)
                    handler.postDelayed({ shootNext() }, interval)
                }
            }
        )
    }

    private fun photosFinished() {
        val cb = onPhotosDone
        onPhotosDone = null
        cb?.invoke()
    }

    // -------------------------------------------------------------- video

    private fun startVideo() {
        val p = provider
        if (!running || videoSeconds <= 0 || p == null) {
            finish()
            return
        }
        try {
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    // SD (480p) keeps the file small so it uploads fast on mobile data
                    QualitySelector.from(
                        Quality.SD, FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                    )
                )
                .build()
            val vc = VideoCapture.withOutput(recorder)
            imageCapture = null
            p.unbindAll()
            p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, vc)

            val name = "thief_video_${stamp()}.mp4"
            val pending = if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AntiTheft")
                }
                recorder.prepareRecording(
                    owner,
                    MediaStoreOutputOptions.Builder(
                        owner.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    ).setContentValues(values).build()
                )
            } else {
                val dir = File(owner.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AntiTheft")
                dir.mkdirs()
                recorder.prepareRecording(owner, FileOutputOptions.Builder(File(dir, name)).build())
            }
            // No audio: video only

            recording = pending.start(ContextCompat.getMainExecutor(owner)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    recording = null
                    val uri = event.outputResults.outputUri
                    if (uri != Uri.EMPTY) onVideo?.invoke(uri)
                    else Log.w(TAG, "Video failed: error ${event.error}")
                    finish()
                }
            }
            handler.postDelayed({ recording?.stop() }, videoSeconds * 1000L)
        } catch (e: Exception) {
            Log.w(TAG, "Video not possible", e)
            finish()
        }
    }

    // ------------------------------------------------------------- common

    private fun finish() {
        val cb = onDone
        stop()
        cb?.invoke()
    }

    fun stop() {
        running = false
        onDone = null
        onPhoto = null
        onPhotosDone = null
        onVideo = null
        handler.removeCallbacksAndMessages(null)
        try { recording?.stop() } catch (_: Exception) {}
        recording = null
        try { provider?.unbindAll() } catch (_: Exception) {}
        provider = null
        imageCapture = null
        remaining = 0
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    private fun photoOptions(): ImageCapture.OutputFileOptions {
        val name = "thief_${stamp()}.jpg"
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AntiTheft")
            }
            currentFile = null
            ImageCapture.OutputFileOptions.Builder(
                owner.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ).build()
        } else {
            val dir = File(owner.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AntiTheft")
            dir.mkdirs()
            val f = File(dir, name)
            currentFile = f
            ImageCapture.OutputFileOptions.Builder(f).build()
        }
    }

    companion object {
        private const val TAG = "ThiefCamera"
    }
}
