package com.example.antitheft

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Silently takes a few photos with the front camera (no preview on screen).
 * Photos are saved to Gallery → Pictures/AntiTheft. If Google Photos backup
 * is on, they are uploaded too, so you can see them even if the phone is gone.
 */
class ThiefCamera(private val owner: LifecycleService) {

    private val handler = Handler(Looper.getMainLooper())
    private var provider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var remaining = 0
    private var interval = 3000L

    fun start(count: Int = 3, intervalMs: Long = 3000) {
        if (ContextCompat.checkSelfPermission(owner, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) return
        if (imageCapture != null) return

        remaining = count
        interval = intervalMs
        val future = ProcessCameraProvider.getInstance(owner)
        future.addListener({
            try {
                val p = future.get()
                val ic = ImageCapture.Builder().build()
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, ic)
                provider = p
                imageCapture = ic
                // give auto-exposure a moment so the photo isn't black
                handler.postDelayed({ shootNext() }, 1500)
            } catch (e: Exception) {
                Log.w(TAG, "Front camera not available", e)
            }
        }, ContextCompat.getMainExecutor(owner))
    }

    private fun shootNext() {
        val ic = imageCapture ?: return
        if (remaining <= 0) {
            stop()
            return
        }
        remaining--
        ic.takePicture(
            outputOptions(),
            ContextCompat.getMainExecutor(owner),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    handler.postDelayed({ shootNext() }, interval)
                }

                override fun onError(e: ImageCaptureException) {
                    Log.w(TAG, "Photo failed", e)
                    handler.postDelayed({ shootNext() }, interval)
                }
            }
        )
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        try { provider?.unbindAll() } catch (_: Exception) {}
        provider = null
        imageCapture = null
        remaining = 0
    }

    private fun outputOptions(): ImageCapture.OutputFileOptions {
        val name = "thief_" +
            SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".jpg"
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AntiTheft")
            }
            ImageCapture.OutputFileOptions.Builder(
                owner.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ).build()
        } else {
            val dir = File(owner.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AntiTheft")
            dir.mkdirs()
            ImageCapture.OutputFileOptions.Builder(File(dir, name)).build()
        }
    }

    companion object {
        private const val TAG = "ThiefCamera"
    }
}
