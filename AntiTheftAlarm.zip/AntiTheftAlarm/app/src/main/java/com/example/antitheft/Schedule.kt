package com.example.antitheft

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.format.DateFormat
import java.util.Calendar
import kotlin.math.min

/** Daily protection window, e.g. 08:00–20:00 or overnight 23:00–07:00. */
object Schedule {

    private fun nowMinutes(): Int {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** True if the schedule is on and the current time is inside the window. */
    fun isActive(c: Context): Boolean {
        if (!Prefs.scheduleEnabled(c)) return false
        val s = Prefs.schedStart(c)
        val e = Prefs.schedEnd(c)
        val now = nowMinutes()
        return when {
            s == e -> true                       // same time = all day
            s < e -> now >= s && now < e         // e.g. 08:00–20:00
            else -> now >= s || now < e          // overnight, e.g. 23:00–07:00
        }
    }

    private fun nextAt(minutes: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun label(c: Context, minutes: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
        }
        return DateFormat.getTimeFormat(c).format(cal.time)
    }

    fun rangeLabel(c: Context) =
        "${label(c, Prefs.schedStart(c))} – ${label(c, Prefs.schedEnd(c))}"

    /** Sets an alarm for the next start or end time, so the service can switch modes. */
    fun scheduleNext(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            c, 10,
            Intent(c, ScheduleReceiver::class.java).setAction(ScheduleReceiver.ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!Prefs.scheduleEnabled(c)) return
        if (Prefs.schedStart(c) == Prefs.schedEnd(c)) return   // all day: nothing to switch
        val t = min(nextAt(Prefs.schedStart(c)), nextAt(Prefs.schedEnd(c)))
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }
}
