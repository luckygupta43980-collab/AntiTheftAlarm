package com.example.antitheft

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper

/** Blinks the flashlight rapidly while the alarm rings. */
class Strobe(ctx: Context) {
    private val cm = ctx.getSystemService(CameraManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var cameraId: String? = null
    private var on = false
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            on = !on
            setTorch(on)
            handler.postDelayed(this, 150)
        }
    }

    fun start() {
        if (running) return
        cameraId = findFlash() ?: return
        running = true
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (on) setTorch(false)
        on = false
    }

    private fun setTorch(v: Boolean) {
        val id = cameraId ?: return
        try { cm?.setTorchMode(id, v) } catch (_: Exception) {}
    }

    private fun findFlash(): String? = try {
        cm?.cameraIdList?.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (_: Exception) {
        null
    }
}
