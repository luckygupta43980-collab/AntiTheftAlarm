package com.example.antitheft

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

/**
 * Loud police-style siren (700 Hz -> 1800 Hz -> 700 Hz sweep), generated in code,
 * so it is always harsh and loud — no matter which alarm ringtone the phone has —
 * and it also works right after a reboot.
 */
class SirenPlayer {
    private var track: AudioTrack? = null

    fun start() {
        if (track != null) return
        val rate = 44100
        val seconds = 1.6                      // one up-and-down sweep
        val n = (rate * seconds).toInt()
        val buf = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n           // 0..1
            val f = if (t < 0.5) 700 + 1100 * (t / 0.5) else 1800 - 1100 * ((t - 0.5) / 0.5)
            phase += 2 * PI * f / rate
            // soft-clipped sine: sounds harsher and louder than a pure tone
            val v = (sin(phase) * 1.8).coerceIn(-1.0, 1.0)
            buf[i] = (v * Short.MAX_VALUE * 0.95).toInt().toShort()
        }

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val format = AudioFormat.Builder()
            .setSampleRate(rate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val t = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(n * 2)
            .build()
        t.write(buf, 0, n)
        t.setLoopPoints(0, n, -1)              // loop forever
        t.setVolume(AudioTrack.getMaxVolume())
        t.play()
        track = t
    }

    fun stop() {
        track?.run {
            try { stop() } catch (_: Exception) {}
            release()
        }
        track = null
    }
}
