package com.example.antitheft

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat

/** Follows the phone's location continuously while the alarm rings. */
class LiveLocation(private val ctx: Context) {
    private val lm = ctx.getSystemService(LocationManager::class.java)
    private var onUpdate: ((Location) -> Unit)? = null
    private var lastSent = 0L

    private val listener = LocationListener { loc ->
        val now = SystemClock.elapsedRealtime()
        if (now - lastSent >= 15_000) {     // move the pin at most every 15 seconds
            lastSent = now
            onUpdate?.invoke(loc)
        }
    }

    /** @param fresh true = live GPS updates allowed (service started from the app) */
    fun start(fresh: Boolean, update: (Location) -> Unit) {
        stop()
        onUpdate = update
        lastSent = 0L
        val fine = granted(Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (lm == null || (!fine && !coarse)) return
        try {
            // Show the last known position right away, then follow live updates
            lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }?.let { lastSent = SystemClock.elapsedRealtime(); update(it) }
            if (!fresh) return
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 10_000L, 5f, listener, Looper.getMainLooper())
                }
            }
        } catch (_: SecurityException) {
        } catch (_: IllegalArgumentException) {
        }
    }

    fun stop() {
        onUpdate = null
        try { lm?.removeUpdates(listener) } catch (_: Exception) {}
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
