package com.example.antitheft

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import kotlin.math.abs

class AlarmService : LifecycleService(), SensorEventListener {

    enum class State { IDLE, COUNTDOWN, ARMED, RINGING }

    companion object {
        const val ACTION_ARM = "com.example.antitheft.ARM"
        const val ACTION_DISARM = "com.example.antitheft.DISARM"
        const val ACTION_TRIGGER = "com.example.antitheft.TRIGGER"
        const val EXTRA_FROM_BOOT = "from_boot"

        private const val CHANNEL_ID = "antitheft"
        private const val CHANNEL_ALERT = "antitheft_alert"
        private const val NOTIF_ID = 1
        private const val BASELINE_SAMPLES = 20
        private const val SMS_REPEAT_MS = 5 * 60_000L   // location update every 5 min
        private const val SMS_MAX_UPDATES = 6           // ... for up to 30 min

        @Volatile var state = State.IDLE
            private set
        @Volatile var countdownLeft = 0
            private set

        fun send(ctx: Context, action: String, fromBoot: Boolean = false) {
            val i = Intent(ctx, AlarmService::class.java)
                .setAction(action)
                .putExtra(EXTRA_FROM_BOOT, fromBoot)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var sensorManager: SensorManager
    private lateinit var audio: AudioManager
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var player: MediaPlayer? = null
    private var tone: ToneGenerator? = null

    private val camera by lazy { ThiefCamera(this) }
    private val sms by lazy { SmsLocationSender(this) }

    private var threshold = 1.5f
    private val baselineSum = FloatArray(3)
    private var baselineCount = 0
    private var smsUpdatesSent = 0

    private var isForeground = false
    private var cameraOk = false
    private var locationOk = false

    private var receiverRegistered = false
    private var chargerRegistered = false
    private var observerRegistered = false

    // ---- Phone unlocked ----
    // ARMED (not ringing yet): owner is using the phone -> quietly switch off.
    // RINGING: keep ringing! Owner must tap STOP ALARM and confirm the PIN.
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_USER_PRESENT) return
            if (state == State.RINGING) showStopPrompt() else disarm()
        }
    }

    // ---- Charger pulled out while armed -> alarm ----
    private val chargerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_POWER_DISCONNECTED && state == State.ARMED) {
                startRinging(fromBoot = false)
            }
        }
    }

    // ---- Volume lock: any volume change is instantly reverted to max ----
    private val volumeObserver = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) = enforceMaxVolume()
    }
    private val volumeGuard = object : Runnable {
        override fun run() {
            if (state == State.RINGING) {
                enforceMaxVolume()
                handler.postDelayed(this, 250)
            }
        }
    }

    private val countdownTick = object : Runnable {
        override fun run() {
            if (state != State.COUNTDOWN) return
            if (countdownLeft <= 0) {
                startDetection()
                return
            }
            updateNotification("Arming in $countdownLeft s — put the phone down")
            countdownLeft--
            handler.postDelayed(this, 1000)
        }
    }

    // Fallback siren if the alarm ringtone can't be played (e.g. right after reboot)
    private val toneLoop = object : Runnable {
        override fun run() {
            tone?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 900)
            handler.postDelayed(this, 1000)
        }
    }

    private val smsRepeat = object : Runnable {
        override fun run() {
            if (state != State.RINGING || smsUpdatesSent >= SMS_MAX_UPDATES) return
            smsUpdatesSent++
            sms.send("Anti-Theft update: alarm is still ringing.", locationOk)
            handler.postDelayed(this, SMS_REPEAT_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        vibrator = getSystemService(Vibrator::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Anti-theft alarm", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Stop alarm prompt", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    setSound(null, null)          // the alarm itself is already loud
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val action = intent?.action
        // Camera + location are only allowed when the user started the service from the app
        ensureForeground(userStarted = action == ACTION_ARM)
        when (action) {
            ACTION_ARM -> startCountdown()
            ACTION_DISARM -> disarm()
            ACTION_TRIGGER -> startRinging(intent.getBooleanExtra(EXTRA_FROM_BOOT, false))
            else -> when { // service was killed and restarted by the system
                Prefs.isRinging(this) -> startRinging(fromBoot = false)
                Prefs.isArmed(this) -> startDetection()
                else -> disarm()
            }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------------ states

    private fun startCountdown() {
        if (state != State.IDLE) return
        Prefs.setArmed(this, true)
        acquireWakeLock()
        registerUnlockReceiver()
        state = State.COUNTDOWN
        countdownLeft = Prefs.delaySeconds(this)
        handler.post(countdownTick)
    }

    private fun startDetection() {
        Prefs.setArmed(this, true)
        acquireWakeLock()
        registerUnlockReceiver()
        threshold = Prefs.threshold(this)
        baselineSum.fill(0f)
        baselineCount = 0
        state = State.ARMED

        if (Prefs.chargerAlarm(this) && !chargerRegistered) {
            ContextCompat.registerReceiver(
                this, chargerReceiver, IntentFilter(Intent.ACTION_POWER_DISCONNECTED),
                ContextCompat.RECEIVER_EXPORTED
            )
            chargerRegistered = true
        }

        val acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc == null) {
            updateNotification("ARMED (charger only) — this phone has no motion sensor")
            return
        }
        sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
        updateNotification("ARMED — alarm will ring if the phone is moved")
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (state != State.ARMED) return
        // First learn the "resting" position by averaging a few samples
        if (baselineCount < BASELINE_SAMPLES) {
            for (i in 0..2) baselineSum[i] += e.values[i]
            baselineCount++
            return
        }
        var diff = 0f
        for (i in 0..2) diff += abs(e.values[i] - baselineSum[i] / baselineCount)
        if (diff > threshold) startRinging(fromBoot = false)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun startRinging(fromBoot: Boolean) {
        if (state == State.RINGING) return
        state = State.RINGING
        Prefs.setArmed(this, true)
        Prefs.setRinging(this, true)   // remembered across a power-off
        sensorManager.unregisterListener(this)
        acquireWakeLock()
        registerUnlockReceiver()

        enforceMaxVolume()
        if (!observerRegistered) {
            contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volumeObserver)
            observerRegistered = true
        }
        handler.post(volumeGuard)

        playSound()
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 400), 0))
        updateNotification("🚨 ALARM! Unlock the phone to stop it")

        if (Prefs.photoEnabled(this) && cameraOk) camera.start()

        if (Prefs.smsEnabled(this)) {
            val msg = if (fromBoot)
                "ANTI-THEFT ALERT: your phone was switched off and turned on again!"
            else
                "ANTI-THEFT ALERT: someone moved your phone!"
            sms.send(msg, locationOk)
            smsUpdatesSent = 0
            handler.postDelayed(smsRepeat, SMS_REPEAT_MS)
        }
    }

    /** Shown after the owner unlocks the phone while the alarm is ringing. */
    private fun showStopPrompt() {
        val open = Intent(this, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_STOP, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🚨 Alarm is still ringing")
            .setContentText("Tap STOP ALARM and confirm your PIN to turn it off")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "STOP ALARM", pi)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
        // Try to open the app directly; newer Android may block this,
        // in which case the notification above is used instead.
        try { startActivity(open) } catch (_: Exception) {}
    }

    private fun disarm() {
        state = State.IDLE
        Prefs.setArmed(this, false)
        Prefs.setRinging(this, false)
        releaseAll()
        stopForeground(STOP_FOREGROUND_REMOVE)
        isForeground = false
        stopSelf()
    }

    // ----------------------------------------------------------------- helpers

    private fun enforceMaxVolume() {
        if (state != State.RINGING) return
        try {
            val stream = AudioManager.STREAM_ALARM
            if (audio.isStreamMute(stream)) {
                audio.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
            }
            val max = audio.getStreamMaxVolume(stream)
            if (audio.getStreamVolume(stream) < max) audio.setStreamVolume(stream, max, 0)
        } catch (_: SecurityException) {
            // Can happen while Do Not Disturb is on; alarm usage still plays in most DND modes
        }
    }

    private fun playSound() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: error("no alarm sound")
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            player?.release()
            player = null
            tone = ToneGenerator(AudioManager.STREAM_ALARM, ToneGenerator.MAX_VOLUME)
            handler.post(toneLoop)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AntiTheft::alarm").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun registerUnlockReceiver() {
        if (receiverRegistered) return
        ContextCompat.registerReceiver(
            this, unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_EXPORTED
        )
        receiverRegistered = true
    }

    private fun releaseAll() {
        handler.removeCallbacksAndMessages(null)
        sensorManager.unregisterListener(this)
        camera.stop()
        sms.stop()
        player?.run { try { stop() } catch (_: Exception) {}; release() }
        player = null
        tone?.release()
        tone = null
        vibrator?.cancel()
        if (observerRegistered) {
            contentResolver.unregisterContentObserver(volumeObserver)
            observerRegistered = false
        }
        if (receiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        if (chargerRegistered) {
            try { unregisterReceiver(chargerReceiver) } catch (_: Exception) {}
            chargerRegistered = false
        }
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun ensureForeground(userStarted: Boolean) {
        if (isForeground) return
        val n = buildNotification(statusText())
        val hasCam = granted(Manifest.permission.CAMERA)
        val hasLoc = granted(Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(Manifest.permission.ACCESS_COARSE_LOCATION)

        if (Build.VERSION.SDK_INT >= 34) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (userStarted && hasCam) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (userStarted && hasLoc) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            try {
                startForeground(NOTIF_ID, n, type)
            } catch (e: Exception) {
                // e.g. started after reboot: camera/location not allowed from the background
                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                startForeground(NOTIF_ID, n, type)
            }
            cameraOk = type and ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA != 0
            locationOk = type and ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION != 0
        } else {
            startForeground(NOTIF_ID, n)
            cameraOk = userStarted && hasCam
            locationOk = userStarted && hasLoc
        }
        isForeground = true
    }

    private fun statusText() = when (state) {
        State.IDLE -> "Starting…"
        State.COUNTDOWN -> "Arming in $countdownLeft s"
        State.ARMED -> "ARMED"
        State.RINGING -> "🚨 ALARM! Unlock the phone to stop it"
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Anti-Theft Alarm")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        // Keep the saved armed/ringing flags so START_STICKY / reboot can resume
        if (state != State.IDLE) releaseAll()
        state = State.IDLE
        isForeground = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
