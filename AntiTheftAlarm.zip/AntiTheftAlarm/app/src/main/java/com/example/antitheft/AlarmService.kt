package com.example.antitheft

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.format.DateFormat
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.Date
import kotlin.math.abs
import kotlin.math.sqrt

class AlarmService : LifecycleService(), SensorEventListener {

    /**
     * IDLE      – nothing running
     * STANDBY   – daily schedule is on, waiting (outside the hours, or phone in use)
     * COUNTDOWN – time to put the phone down
     * ARMED     – protected: touching the phone starts the alarm
     * RINGING   – alarm is ringing
     */
    enum class State { IDLE, STANDBY, COUNTDOWN, ARMED, RINGING }

    companion object {
        const val ACTION_ARM = "com.example.antitheft.ARM"
        const val ACTION_DISARM = "com.example.antitheft.DISARM"
        const val ACTION_TRIGGER = "com.example.antitheft.TRIGGER"
        const val ACTION_SCHEDULE = "com.example.antitheft.SCHEDULE"
        const val EXTRA_FROM_BOOT = "from_boot"
        const val EXTRA_FROM_APP = "from_app"

        const val SOURCE_MANUAL = "manual"
        const val SOURCE_SCHEDULE = "schedule"

        private const val TAG = "AlarmService"
        private const val CHANNEL_ID = "antitheft"
        private const val CHANNEL_ALERT = "antitheft_alert"
        private const val NOTIF_ID = 1
        private const val DONE_NOTIF_ID = 2

        private const val SETTLE_MS = 1500L
        private const val BASELINE_MS = 1000L
        // CallMeBot allows only ~25 WhatsApp messages per 4 hours, so: every 10 minutes
        private const val TRACK_MS = 10 * 60_000L
        private const val SMS_EVERY_TICKS = 3
        // Telegram: new photo + video clip every 5 minutes while ringing
        // (location is shared LIVE the whole time)
        private const val CAPTURE_MS = 5 * 60_000L
        private const val CLIP_SECONDS = 10

        @Volatile var state = State.IDLE
            private set
        @Volatile var countdownLeft = 0
            private set
        @Volatile var warning = false
            private set
        @Volatile var warningLeft = 0
            private set

        fun send(ctx: Context, action: String, fromBoot: Boolean = false, fromApp: Boolean = false) {
            val i = Intent(ctx, AlarmService::class.java)
                .setAction(action)
                .putExtra(EXTRA_FROM_BOOT, fromBoot)
                .putExtra(EXTRA_FROM_APP, fromApp)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot start service", e)
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var sensorManager: SensorManager
    private lateinit var audio: AudioManager
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val siren = SirenPlayer()
    private var tone: ToneGenerator? = null
    private var warnTone: ToneGenerator? = null

    private val strobe by lazy { Strobe(this) }
    private val camera by lazy { ThiefCamera(this) }
    private val alerts by lazy { AlertSender(this) }
    private val live by lazy { LiveLocation(this) }

    private var accThreshold = 1.2f
    private var gyroThreshold = 0.3f
    private var hitsNeeded = 2
    private var detectStart = 0L
    private val baseSum = FloatArray(3)
    private var baseCount = 0
    private var accHits = 0
    private var gyroHits = 0

    private var trackTicks = 0
    private var updateNo = 0
    @Volatile private var lastLoc: Location? = null
    private var isForeground = false
    private var cameraOk = false
    private var locationOk = false
    private var observerRegistered = false
    private val registered = mutableSetOf<BroadcastReceiver>()

    // ------------------------------------------------------------ receivers

    // Unlocked by the owner. Ringing: keep ringing until STOP + PIN. Otherwise: stand down.
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_USER_PRESENT) return
            if (state == State.RINGING) showStopPrompt() else disarm()
        }
    }

    private val chargerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_POWER_DISCONNECTED && state == State.ARMED) trigger()
        }
    }

    // Screen turned on while protected (option)
    private val screenOnReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_SCREEN_ON || state != State.ARMED) return
            val mode = audio.mode
            if (mode == AudioManager.MODE_RINGTONE || mode == AudioManager.MODE_IN_CALL ||
                mode == AudioManager.MODE_IN_COMMUNICATION
            ) return
            trigger()
        }
    }

    // Schedule: screen locked during the protected hours -> start protection
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && state == State.STANDBY &&
                Schedule.isActive(c)
            ) startCountdown(SOURCE_SCHEDULE)
        }
    }

    private val volumeObserver = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) = enforceMaxVolume()
    }
    private val volumeGuard = object : Runnable {
        override fun run() {
            if (state == State.RINGING) {
                enforceMaxVolume()
                handler.postDelayed(this, 250)
            }
        }
    }

    // ------------------------------------------------------------ timers

    private val countdownTick = object : Runnable {
        override fun run() {
            if (state != State.COUNTDOWN) return
            if (countdownLeft <= 0) {
                startDetection(fresh = true)
                return
            }
            updateNotification("Put the phone down — protection starts in $countdownLeft s")
            countdownLeft--
            handler.postDelayed(this, 1000)
        }
    }

    private val protectionEnd = Runnable {
        if (state == State.ARMED && !warning) {
            notifyProtectionDone()
            disarm()
        }
    }

    private val warningTick = object : Runnable {
        override fun run() {
            if (!warning || state != State.ARMED) return
            if (warningLeft <= 0) {
                warning = false
                startRinging(fromBoot = false)
                return
            }
            // Owner check: silent, vibration only — the owner unlocks, a thief can't
            try { vibrator?.vibrate(VibrationEffect.createOneShot(500, 255)) } catch (_: Exception) {}
            updateNotification("🔐 Owner check: unlock with your fingerprint — alarm in $warningLeft s")
            warningLeft--
            handler.postDelayed(this, 1000)
        }
    }

    private val toneLoop = object : Runnable {
        override fun run() {
            tone?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 900)
            handler.postDelayed(this, 1000)
        }
    }

    private val tracker = object : Runnable {
        override fun run() {
            if (state != State.RINGING) return
            trackTicks++
            val smsNow = trackTicks % SMS_EVERY_TICKS == 0
            alerts.send(
                "📍 LIVE LOCATION UPDATE — alarm still ringing",
                locationOk, useSms = smsNow, useWa = true, onlyIfMoved = !smsNow
            )
            handler.postDelayed(this, TRACK_MS)
        }
    }

    // Every 5 minutes while ringing: 1 photo + 10-second video on Telegram
    private val captureCycle = object : Runnable {
        override fun run() {
            if (state != State.RINGING) return
            updateNo++
            val n = updateNo
            if (TelegramBot.ready(this@AlarmService)) {
                val caption = updateText(n)
                val wantPhotos = Prefs.photoEnabled(this@AlarmService)
                val wantVideo = Prefs.videoEnabled(this@AlarmService)
                if (!(wantPhotos || wantVideo) || !cameraOk) {
                    TelegramBot.sendMessage(this@AlarmService, caption)
                } else {
                    strobe.stop()   // the camera is busy for a moment
                    camera.start(
                        photoCount = if (wantPhotos) 1 else 0,
                        videoSecs = if (wantVideo) CLIP_SECONDS else 0,
                        photo = { TelegramBot.sendPhoto(this@AlarmService, it, "📸 $caption") },
                        video = { TelegramBot.sendVideo(this@AlarmService, it, "🎥 $caption") },
                        done = {
                            if (state == State.RINGING && Prefs.flashEnabled(this@AlarmService)) {
                                strobe.start()
                            }
                        }
                    )
                }
            }
            handler.postDelayed(this, CAPTURE_MS)
        }
    }

    /** Short caption; the location itself is the live map pin in the chat. */
    private fun updateText(n: Int): String {
        val time = DateFormat.getTimeFormat(this).format(Date())
        val battery = try {
            getSystemService(BatteryManager::class.java)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (_: Exception) { -1 }
        return "UPDATE #$n — $time — alarm still ringing — battery $battery%"
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        vibrator = getSystemService(Vibrator::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Anti-theft alarm", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Stop alarm prompt", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    setSound(null, null)
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val action = intent?.action
        val fromApp = action == ACTION_ARM || intent?.getBooleanExtra(EXTRA_FROM_APP, false) == true
        val fromBoot = intent?.getBooleanExtra(EXTRA_FROM_BOOT, false) == true
        ensureForeground(fromApp)
        when (action) {
            ACTION_ARM -> startCountdown(SOURCE_MANUAL)
            ACTION_DISARM -> disarm()
            ACTION_TRIGGER -> if (fromBoot) startRinging(fromBoot = true) else trigger()
            ACTION_SCHEDULE -> applySchedule()
            else -> when { // restarted by the system after being killed
                Prefs.isRinging(this) -> startRinging(fromBoot = false)
                Prefs.isArmed(this) -> startDetection(fresh = false)
                Prefs.scheduleEnabled(this) -> applySchedule()
                else -> shutdown()
            }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------ schedule

    private fun applySchedule() {
        Schedule.scheduleNext(this)
        if (!Prefs.scheduleEnabled(this)) {
            if (state == State.STANDBY || state == State.IDLE) shutdown()
            return
        }
        val inWindow = Schedule.isActive(this)
        when (state) {
            State.RINGING -> return
            State.ARMED, State.COUNTDOWN -> {
                // End of the daily hours: stop scheduled protection (manual protection continues)
                if (!inWindow && !warning && Prefs.armSource(this) == SOURCE_SCHEDULE) {
                    releaseAll()
                    Prefs.setArmed(this, false)
                    enterStandby()
                }
            }
            State.IDLE, State.STANDBY -> {
                if (state == State.IDLE) enterStandby()
                if (inWindow && !phoneInUse()) startCountdown(SOURCE_SCHEDULE)
                else updateNotification(standbyText())
            }
        }
    }

    private fun enterStandby() {
        state = State.STANDBY
        listen(screenOffReceiver, Intent.ACTION_SCREEN_OFF)
        updateNotification(standbyText())
    }

    private fun phoneInUse(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        return pm.isInteractive && !km.isKeyguardLocked
    }

    private fun standbyText(): String =
        if (Schedule.isActive(this))
            "🕗 Daily protection (${Schedule.rangeLabel(this)}): starts when you lock the screen"
        else
            "🕗 Daily protection ${Schedule.rangeLabel(this)} — next start " +
                Schedule.label(this, Prefs.schedStart(this))

    // ------------------------------------------------------------ protection

    private fun startCountdown(source: String) {
        if (state != State.IDLE && state != State.STANDBY) return
        getSystemService(NotificationManager::class.java).cancel(DONE_NOTIF_ID)
        releaseAll()
        Prefs.setArmSource(this, source)
        Prefs.setArmed(this, true)
        Prefs.setProtectUntil(this, 0L)
        acquireWakeLock()
        listen(unlockReceiver, Intent.ACTION_USER_PRESENT)
        state = State.COUNTDOWN
        countdownLeft = Prefs.delaySeconds(this)
        handler.post(countdownTick)
    }

    private fun startDetection(fresh: Boolean) {
        Prefs.setArmed(this, true)
        acquireWakeLock()
        listen(unlockReceiver, Intent.ACTION_USER_PRESENT)
        loadSensitivity()
        state = State.ARMED
        warning = false

        val manual = Prefs.armSource(this) == SOURCE_MANUAL
        if (fresh && manual) {
            val secs = Prefs.protectSeconds(this)
            Prefs.setProtectUntil(
                this, if (secs > 0) System.currentTimeMillis() + secs * 1000L else 0L
            )
        }
        val until = if (manual) Prefs.protectUntil(this) else 0L
        if (until > 0) {
            val left = until - System.currentTimeMillis()
            if (left <= 0) {
                handler.post(protectionEnd)
                return
            }
            handler.postDelayed(protectionEnd, left)
        }
        if (!manual) Schedule.scheduleNext(this)

        if (Prefs.chargerAlarm(this)) listen(chargerReceiver, Intent.ACTION_POWER_DISCONNECTED)
        if (Prefs.screenAlarm(this)) listen(screenOnReceiver, Intent.ACTION_SCREEN_ON)

        detectStart = SystemClock.uptimeMillis()
        baseSum.fill(0f)
        baseCount = 0
        accHits = 0
        gyroHits = 0
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        if (fresh) beep()
        updateNotification(armedText())
    }

    private fun loadSensitivity() {
        when (Prefs.sensitivity(this)) {
            0 -> { accThreshold = 2.5f; gyroThreshold = 0.6f; hitsNeeded = 3 }
            2 -> { accThreshold = 0.5f; gyroThreshold = 0.12f; hitsNeeded = 1 }
            else -> { accThreshold = 1.2f; gyroThreshold = 0.3f; hitsNeeded = 2 }
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (state != State.ARMED || warning) return
        val elapsed = SystemClock.uptimeMillis() - detectStart
        if (elapsed < SETTLE_MS) return
        when (e.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                if (elapsed < SETTLE_MS + BASELINE_MS) {
                    for (i in 0..2) baseSum[i] += e.values[i]
                    baseCount++
                    return
                }
                if (baseCount == 0) return
                var diff = 0f
                for (i in 0..2) diff += abs(e.values[i] - baseSum[i] / baseCount)
                accHits = if (diff > accThreshold) accHits + 1 else 0
                if (accHits >= hitsNeeded) trigger()
            }
            Sensor.TYPE_GYROSCOPE -> {
                val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
                gyroHits = if (sqrt(x * x + y * y + z * z) > gyroThreshold) gyroHits + 1 else 0
                if (gyroHits >= hitsNeeded) trigger()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /**
     * Someone touched the phone. With "Owner check" on: silent vibration for a few seconds —
     * if the owner unlocks (fingerprint / face / PIN) nothing happens; otherwise the siren starts.
     */
    private fun trigger() {
        if (state != State.ARMED || warning) return
        val grace = Prefs.graceSeconds(this)
        if (grace <= 0) {
            startRinging(fromBoot = false)
            return
        }
        warning = true
        warningLeft = grace
        sensorManager.unregisterListener(this)
        handler.removeCallbacks(protectionEnd)
        handler.post(warningTick)
    }

    private fun startRinging(fromBoot: Boolean) {
        if (state == State.RINGING) return
        state = State.RINGING
        warning = false
        warnTone?.release()
        warnTone = null
        Prefs.setArmed(this, true)
        Prefs.setRinging(this, true)
        handler.removeCallbacks(protectionEnd)
        handler.removeCallbacks(countdownTick)
        handler.removeCallbacks(warningTick)
        sensorManager.unregisterListener(this)
        acquireWakeLock()
        listen(unlockReceiver, Intent.ACTION_USER_PRESENT)

        enforceMaxVolume()
        if (!observerRegistered) {
            contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volumeObserver)
            observerRegistered = true
        }
        handler.post(volumeGuard)

        try {
            siren.start()
        } catch (e: Exception) {
            tone = ToneGenerator(AudioManager.STREAM_ALARM, ToneGenerator.MAX_VOLUME)
            handler.post(toneLoop)
        }

        vibrateMax()
        updateNotification("🚨 ALARM! Unlock the phone, then tap STOP ALARM")

        val flash = Prefs.flashEnabled(this)
        val wantPhotos = Prefs.photoEnabled(this)
        val wantVideo = Prefs.videoEnabled(this)
        if ((wantPhotos || wantVideo) && cameraOk) {
            val photos = mutableListOf<Uri>()
            camera.start(
                photoCount = if (wantPhotos) 3 else 0,
                videoSecs = if (wantVideo) 20 else 0,
                photo = {
                    photos += it
                    TelegramBot.sendPhoto(this, it, "📸 Person who touched your phone")
                },
                photosDone = { alerts.sendPhotos(photos.toList()) },
                video = {
                    alerts.sendVideo(it)
                    TelegramBot.sendVideo(this, it, "🎥 Video of the person who touched your phone")
                },
                done = { if (state == State.RINGING && flash) strobe.start() }
            )
        } else if (flash) {
            strobe.start()
        }

        // Telegram: alert + LIVE location pin that keeps moving
        if (TelegramBot.ready(this)) {
            TelegramBot.sendMessage(
                this,
                if (fromBoot) "🚨 ANTI-THEFT ALERT: your phone was switched off and turned on again!"
                else "🚨 ANTI-THEFT ALERT: someone touched your phone!\n" +
                    "📍 Live location follows. Photos and video will arrive here."
            )
            lastLoc = null
            live.start(locationOk) {
                lastLoc = it
                TelegramBot.updateLive(this, it)
            }
            updateNo = 0
            handler.postDelayed(captureCycle, CAPTURE_MS)
        }

        if (Prefs.smsEnabled(this) || Prefs.waEnabled(this)) {
            val msg = if (fromBoot)
                "🚨 ANTI-THEFT ALERT: your phone was switched off and turned on again!"
            else
                "🚨 ANTI-THEFT ALERT: someone touched your phone!"
            alerts.send(msg, locationOk)
            trackTicks = 0
            handler.postDelayed(tracker, TRACK_MS)
        }
    }

    private fun showStopPrompt() {
        val open = Intent(this, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_STOP, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🚨 Alarm is still ringing")
            .setContentText("Tap STOP ALARM and confirm your PIN to turn it off")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "STOP ALARM", pi)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
        try { startActivity(open) } catch (_: Exception) {}
    }

    /** Stop protection / alarm. With the daily schedule on, go back to waiting. */
    private fun disarm() {
        if (state == State.RINGING) {
            TelegramBot.stopLive(this, "✅ Alarm stopped with your PIN.")
        }
        releaseAll()
        state = State.IDLE
        Prefs.setArmed(this, false)
        Prefs.setRinging(this, false)
        Prefs.setProtectUntil(this, 0L)
        if (Prefs.scheduleEnabled(this)) {
            enterStandby()
            applySchedule()
        } else {
            shutdown()
        }
    }

    private fun shutdown() {
        releaseAll()
        state = State.IDLE
        Prefs.setArmed(this, false)
        Prefs.setRinging(this, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        isForeground = false
        stopSelf()
    }

    // ------------------------------------------------------------ helpers

    private fun armedText(): String {
        if (Prefs.armSource(this) == SOURCE_SCHEDULE) {
            return "PROTECTED (daily, until ${Schedule.label(this, Prefs.schedEnd(this))}) — " +
                "alarm rings if anyone touches the phone"
        }
        val until = Prefs.protectUntil(this)
        return if (until > 0)
            "PROTECTED until ${DateFormat.getTimeFormat(this).format(Date(until))} — " +
                "alarm rings if anyone touches the phone"
        else
            "PROTECTED — alarm rings if anyone touches the phone"
    }

    private fun beep() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_ALARM, 50)
            t.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
            handler.postDelayed({ t.release() }, 800)
        } catch (_: Exception) {}
    }

    private fun vibrateMax() {
        try {
            val effect = VibrationEffect.createWaveform(
                longArrayOf(0, 1000, 150), intArrayOf(0, 255, 0), 0
            )
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            @Suppress("DEPRECATION")
            vibrator?.vibrate(effect, attrs)
        } catch (_: Exception) {}
    }

    private fun notifyProtectionDone() {
        val pi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("✅ Protection time is over")
            .setContentText("Nobody touched your phone.")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        getSystemService(NotificationManager::class.java).notify(DONE_NOTIF_ID, n)
    }

    private fun enforceMaxVolume() {
        if (state != State.RINGING) return
        try {
            val stream = AudioManager.STREAM_ALARM
            if (audio.isStreamMute(stream)) {
                audio.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
            }
            val max = audio.getStreamMaxVolume(stream)
            if (audio.getStreamVolume(stream) < max) audio.setStreamVolume(stream, max, 0)
        } catch (_: SecurityException) {
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AntiTheft::alarm").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun listen(r: BroadcastReceiver, action: String) {
        if (r in registered) return
        ContextCompat.registerReceiver(this, r, IntentFilter(action), ContextCompat.RECEIVER_EXPORTED)
        registered += r
    }

    private fun releaseAll() {
        warning = false
        handler.removeCallbacksAndMessages(null)
        sensorManager.unregisterListener(this)
        siren.stop()
        strobe.stop()
        camera.stop()
        alerts.stop()
        live.stop()
        tone?.release()
        tone = null
        warnTone?.release()
        warnTone = null
        vibrator?.cancel()
        if (observerRegistered) {
            contentResolver.unregisterContentObserver(volumeObserver)
            observerRegistered = false
        }
        registered.forEach { try { unregisterReceiver(it) } catch (_: Exception) {} }
        registered.clear()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /**
     * Camera and location are only allowed when the service was started from the app.
     * If the app is opened later, the service is "upgraded" to get them.
     */
    private fun ensureForeground(fromApp: Boolean) {
        val hasCam = granted(Manifest.permission.CAMERA)
        val hasLoc = granted(Manifest.permission.ACCESS_FINE_LOCATION) ||
            granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        val upgrade = fromApp && ((hasCam && !cameraOk) || (hasLoc && !locationOk))
        if (isForeground && !upgrade) return

        val n = buildNotification(statusText())
        if (Build.VERSION.SDK_INT >= 34) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (fromApp && hasCam) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (fromApp && hasLoc) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            try {
                startForeground(NOTIF_ID, n, type)
            } catch (e: Exception) {
                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                startForeground(NOTIF_ID, n, type)
            }
            cameraOk = type and ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA != 0
            locationOk = type and ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION != 0
        } else {
            startForeground(NOTIF_ID, n)
            if (fromApp) {
                cameraOk = hasCam
                locationOk = hasLoc
            }
        }
        isForeground = true
    }

    private fun statusText() = when (state) {
        State.IDLE -> "Starting…"
        State.STANDBY -> standbyText()
        State.COUNTDOWN -> "Put the phone down — protection starts in $countdownLeft s"
        State.ARMED -> armedText()
        State.RINGING -> "🚨 ALARM! Unlock the phone, then tap STOP ALARM"
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Anti-Theft Alarm")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        if (state != State.IDLE) releaseAll()
        state = State.IDLE
        isForeground = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
