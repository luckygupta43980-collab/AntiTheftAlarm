package com.example.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fires at the schedule's start/end times (and when the clock or time zone changes). */
class ScheduleReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_TICK = "com.example.antitheft.SCHEDULE_TICK"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs.scheduleEnabled(context)) return
        AlarmService.send(context, AlarmService.ACTION_SCHEDULE)
    }
}
