plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ============================================================================
//  YOUR APP'S UNIQUE ID ON GOOGLE PLAY.
//  Change it to your own (lowercase, dots, no spaces) BEFORE the first upload.
//  It can NEVER be changed after the app is published.
// ============================================================================
val appId = "com.luckygupta.antitheftalarm"

android {
    namespace = "com.example.antitheft"
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        minSdk = 26
        targetSdk = 36
        // Every GitHub build gets a higher number (Google Play requires this)
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "2.0"
    }

    buildFeatures {
        buildConfig = true
    }

    flavorDimensions += "store"
    productFlavors {
        // Google Play version: follows Play policies
        create("play") {
            dimension = "store"
            buildConfigField("boolean", "FEATURE_SMS", "false")
            buildConfigField("boolean", "FEATURE_POWER_BLOCK", "false")
        }
        // Sideload version for your own phone: all features
        create("full") {
            dimension = "store"
            applicationIdSuffix = ".full"
            versionNameSuffix = "-full"
            buildConfigField("boolean", "FEATURE_SMS", "true")
            buildConfigField("boolean", "FEATURE_POWER_BLOCK", "true")
        }
    }

    // Private upload key: provided by GitHub Secrets, never stored in the project
    val uploadKeystore = System.getenv("UPLOAD_KEYSTORE_FILE")

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            if (uploadKeystore != null) {
                storeFile = file(uploadKeystore)
                storePassword = System.getenv("UPLOAD_KEYSTORE_PASSWORD")
                keyAlias = "upload"
                keyPassword = System.getenv("UPLOAD_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            if (uploadKeystore != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")

    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-video:1.4.1")
}
